# Lab 5: Image Stitching - Pseudocode

## Overview
Lab 5 focuses on implementing an end-to-end image stitching pipeline to combine two overlapping images into a single panoramic image. The pipeline includes feature detection, matching, geometric alignment, and blending techniques.

---

# IMAGE STITCHING PIPELINE

## High-Level Workflow

```
INPUT: Two overlapping images (img1, img2)

STEP 1: Preprocessing
  ├─ Load images in RGB color space
  ├─ Color and exposure correction (histogram matching)
  └─ OUTPUT: Preprocessed images

STEP 2: Feature Detection & Matching
  ├─ Detect SIFT keypoints and descriptors in both images
  ├─ Match descriptors using Brute Force Matcher
  ├─ Filter matches using Lowe's ratio test
  └─ OUTPUT: Good matched keypoint pairs

STEP 3: Geometric Alignment
  ├─ Compute homography matrix using RANSAC
  ├─ Calculate reprojection error
  ├─ Determine output canvas size
  └─ OUTPUT: Homography matrix with translation

STEP 4: Image Warping & Placement
  ├─ Warp image 1 using homography with translation
  ├─ Place image 2 on the output canvas
  └─ OUTPUT: Aligned images with potential overlap

STEP 5: Overlap Detection & Blending
  ├─ Create binary masks for both images
  ├─ Detect overlap region
  ├─ Compute gradient blending masks
  ├─ Blend images in overlap region
  └─ OUTPUT: Final stitched panoramic image

OUTPUT: Blended panoramic image
```

---

# PART 1: PREPROCESSING

**Objective**: Prepare images for feature matching by correcting exposure and color differences.

## Pseudocode - Image Loading and Color Conversion

```
FUNCTION load_and_convert_images(image_path1, image_path2):
  """
  Load images and convert from BGR to RGB
  """
  
  INPUT:
    - image_path1: Path to first image
    - image_path2: Path to second image
  
  STEP 1: Load images
    img1_bgr = read_image(image_path1, color_space=BGR)
    img2_bgr = read_image(image_path2, color_space=BGR)
  
  STEP 2: Convert to RGB
    img1 = convert_color_space(img1_bgr, BGR_to_RGB)
    img2 = convert_color_space(img2_bgr, BGR_to_RGB)
  
  STEP 3: Verify dimensions
    IF img1.shape[2] != 3 OR img2.shape[2] != 3:
      ERROR: "Images must be 3-channel color images"
  
  RETURN img1, img2
```

## Pseudocode - Histogram Matching for Exposure/Color Correction

```
FUNCTION match_histogram_exposure(src_image, ref_image):
  """
  Adjust source image to match reference image's histogram
  Corrects color and exposure differences
  """
  
  INPUT:
    - src_image: Source image to adjust
    - ref_image: Reference image (target histogram)
  
  STEP 1: Apply histogram matching
    adjusted_image = match_histograms(
      src_image,
      ref_image,
      channel_axis=-1  /* Match per-channel histograms */
    )
    
    /* Per-channel matching:
       For each RGB channel:
         - Compute histogram of reference channel
         - Remap source channel intensities to match reference histogram
         - Result: Similar color temperature and brightness
    */
  
  STEP 2: Clip to valid range
    adjusted_image = clip(adjusted_image, 0, 255)
  
  RETURN adjusted_image
```

## Why Preprocessing Matters

```
Effect on stitching:
  Without preprocessing:
    - Exposure differences create visible seams at borders
    - Color temperature shifts between images
    - Blending algorithms struggle to smooth transitions
    - Final panorama looks disjointed
  
  With preprocessing:
    - Similar exposure and colors throughout
    - Blending transitions appear natural
    - Fewer visible artifacts in overlap region
    - Higher-quality final panorama
```

---

# PART 2: FEATURE DETECTION AND MATCHING

**Objective**: Find corresponding points between images for alignment.

## Pseudocode - SIFT Feature Detection

```
FUNCTION detect_sift_features(image):
  """
  Detect Scale-Invariant Feature Transform (SIFT) keypoints and descriptors
  """
  
  INPUT:
    - image: Grayscale or color image
  
  STEP 1: Initialize SIFT detector
    sift = SIFT_create()
  
  STEP 2: Detect keypoints and compute descriptors
    keypoints, descriptors = sift.detectAndCompute(
      image,
      mask=None  /* Apply to entire image */
    )
    
    /* Each keypoint contains:
       - pt: (x, y) location
       - size: Characteristic scale (octave)
       - angle: Orientation angle
       - response: Strength/cornerness
       - octave: Pyramid level
       
       Each descriptor: 128-dimensional vector
         - Encodes local gradient information
         - Invariant to scale, rotation, lighting
    */
  
  RETURN keypoints, descriptors
```

## Pseudocode - Feature Matching

```
FUNCTION match_features(descriptors1, descriptors2):
  """
  Match SIFT descriptors between two images using Brute Force Matcher
  """
  
  INPUT:
    - descriptors1: N×128 descriptor array from image 1
    - descriptors2: M×128 descriptor array from image 2
  
  STEP 1: Initialize Brute Force Matcher
    matcher = BFMatcher(
      norm_type=NORM_L2,    /* Euclidean distance */
      cross_check=False     /* No cross-checking yet */
    )
  
  STEP 2: Perform k-NN matching
    matches = matcher.knnMatch(
      descriptors1,
      descriptors2,
      k=2  /* Find 2 nearest neighbors */
    )
    
    /* For each descriptor in image 1:
       - Find 2 closest descriptors in image 2
       - Returns tuples: (best_match, second_best_match)
    */
  
  RETURN matches
```

## Pseudocode - Lowe's Ratio Test

```
FUNCTION filter_matches_by_ratio_test(matches, ratio_threshold=0.7):
  """
  Apply Lowe's ratio test to filter good matches
  Removes ambiguous matches where best and second-best are too similar
  """
  
  INPUT:
    - matches: List of (best_match, second_best_match) tuples
    - ratio_threshold: Threshold for good matches (typically 0.7)
  
  OUTPUT:
    - good_matches: Filtered list of good matches
  
  INITIALIZATION:
    good_matches = []
  
  MAIN LOOP:
    FOR each (best_match, second_best_match) in matches:
      
      STEP 1: Extract distances
        dist_best = best_match.distance
        dist_second = second_best_match.distance
      
      STEP 2: Apply ratio test
        IF dist_best < ratio_threshold * dist_second:
          /* Best match is distinctly better than second-best
             Indicates confident, unambiguous match */
          good_matches.append(best_match)
      
      ELSE:
        /* Ambiguous match, could match multiple features
           Skip to avoid false correspondences */
        CONTINUE
  
  RETURN good_matches
```

## Feature Matching Workflow Visualization

```
Image 1 Descriptors          Image 2 Descriptors
      ↓                              ↓
   (128-dim)                     (128-dim)
      ↓                              ↓
      └──── BFMatcher ────────────────┘
           (k-NN, k=2)
               ↓
        2 closest neighbors
        for each descriptor
               ↓
        (best, second_best)
               ↓
      Lowe's Ratio Test
      (best < 0.7 * second_best)
               ↓
       Good Matches Only
```

---

# PART 3: GEOMETRIC ALIGNMENT

**Objective**: Compute homography matrix to align images and handle perspective distortion.

## Pseudocode - Extract Matched Points

```
FUNCTION extract_matched_points(keypoints1, keypoints2, good_matches):
  """
  Extract 2D coordinates from matched keypoints
  """
  
  INPUT:
    - keypoints1: Keypoints from image 1
    - keypoints2: Keypoints from image 2
    - good_matches: Filtered match objects
  
  STEP 1: Extract coordinates from keypoints1
    points1 = [keypoints1[match.queryIdx].pt for match in good_matches]
    /* Each pt is (x, y) coordinate */
    
    points1 = convert_to_float32_array(points1)
    points1 = reshape(points1, -1, 1, 2)
    /* Shape: (N, 1, 2) for OpenCV compatibility */
  
  STEP 2: Extract coordinates from keypoints2
    points2 = [keypoints2[match.trainIdx].pt for match in good_matches]
    
    points2 = convert_to_float32_array(points2)
    points2 = reshape(points2, -1, 1, 2)
  
  RETURN points1, points2
```

## Pseudocode - Compute Homography with RANSAC

```
FUNCTION compute_homography_ransac(points1, points2, threshold=5.0):
  """
  Compute homography matrix using RANSAC to handle outliers
  Maps points from image1 to image2 coordinate system
  """
  
  INPUT:
    - points1: N×1×2 array of points from image 1
    - points2: N×1×2 array of points from image 2
    - threshold: RANSAC inlier threshold (pixels)
  
  OUTPUT:
    - H: 3×3 homography matrix
    - mask: N×1 binary array (1=inlier, 0=outlier)
  
  STEP 1: Perform RANSAC
    H, mask = findHomography(
      points1,
      points2,
      method=RANSAC,
      ransac_reprojection_threshold=threshold,
      confidence=0.99  /* 99% confidence in solution */
    )
    
    /* RANSAC algorithm (inside):
       Repeat for max_iterations:
         1. Sample 4 random point correspondences
         2. Compute homography from these 4 points
         3. Count inliers (points close to projection)
         4. Track best solution (most inliers)
       Return best homography and inlier mask
    */
  
  STEP 2: Verify solution
    IF H is None:
      ERROR: "Could not find homography. Poor feature matches."
  
  RETURN H, mask
```

## Homography Matrix Structure

```
H = [[h11, h12, h13],
     [h21, h22, h23],
     [h31, h32, h33]]

Usage for point projection:
  p' = H @ p_homogeneous
  
Where:
  p_homogeneous = [x, y, 1]^T
  p' = [x', y', z']^T
  
Normalized image coordinates:
  x_final = x' / z'
  y_final = y' / z'
```

## Pseudocode - Reprojection Error

```
FUNCTION compute_reprojection_error(points1, points2, H):
  """
  Measure accuracy by comparing detected vs projected points
  """
  
  INPUT:
    - points1: Detected points in image 1 (N×1×2)
    - points2: Detected points in image 2 (N×1×2)
    - H: Homography matrix (3×3)
  
  STEP 1: Project points1 using homography
    points1_projected = perspectiveTransform(points1, H)
    /* Apply H to map points1 to image2 coordinate system */
  
  STEP 2: Compute errors
    FOR each point i:
      projected = points1_projected[i]
      actual = points2[i]
      error[i] = euclidean_distance(projected, actual)
      /* L2 norm: sqrt((proj_x - actual_x)² + (proj_y - actual_y)²) */
  
  STEP 3: Compute mean error
    mean_error = mean(error)
    
    /* Interpretation:
       < 1.0 pixel: Excellent alignment
       1.0 - 3.0 pixels: Good alignment
       > 5.0 pixels: Poor alignment, investigate matches
    */
  
  RETURN mean_error
```

---

# PART 4: IMAGE WARPING AND PLACEMENT

**Objective**: Warp and place images on output canvas with proper alignment.

## Pseudocode - Compute Output Canvas Size

```
FUNCTION compute_output_canvas(img1_shape, H, img2_shape):
  """
  Determine output canvas size by finding bounding box of warped images
  """
  
  INPUT:
    - img1_shape: (height, width) of image 1
    - H: Homography matrix
    - img2_shape: (height, width) of image 2
  
  STEP 1: Define corners of image 1
    h1, w1 = img1_shape
    corners1 = [[0, 0],      /* Top-left */
                [0, h1],     /* Bottom-left */
                [w1, h1],    /* Bottom-right */
                [w1, 0]]     /* Top-right */
    
    corners1 = convert_to_float32_homogeneous(corners1)
    /* Shape: (4, 1, 2) */
  
  STEP 2: Transform corners using homography
    corners1_transformed = perspectiveTransform(corners1, H)
    /* Project corners from image1 to image2 coordinate system */
  
  STEP 3: Compute bounding box of transformed image 1
    x_min1 = min(corners1_transformed[:, 0])
    y_min1 = min(corners1_transformed[:, 1])
    x_max1 = max(corners1_transformed[:, 0])
    y_max1 = max(corners1_transformed[:, 1])
  
  STEP 4: Image 2 bounding box (already in this coordinate system)
    x_min2 = 0
    y_min2 = 0
    h2, w2 = img2_shape
    x_max2 = w2
    y_max2 = h2
  
  STEP 5: Compute final canvas size
    canvas_x_min = min(x_min1, x_min2)
    canvas_y_min = min(y_min1, y_min2)
    canvas_x_max = max(x_max1, x_max2)
    canvas_y_max = max(y_max1, y_max2)
    
    canvas_width = int(canvas_x_max - canvas_x_min + 0.5)
    canvas_height = int(canvas_y_max - canvas_y_min + 0.5)
  
  STEP 6: Compute translation to fit canvas
    translation = [-canvas_x_min, -canvas_y_min]
    /* Shift so that minimum coordinates become (0, 0) */
  
  RETURN (canvas_width, canvas_height), translation
```

## Pseudocode - Create Translation-Adjusted Homography

```
FUNCTION create_homography_with_translation(H, translation):
  """
  Embed translation into homography matrix
  Ensures warped image fits in positive coordinate system
  """
  
  INPUT:
    - H: Original homography matrix (3×3)
    - translation: [tx, ty] translation vector
  
  STEP 1: Create translation matrix
    T = [[1, 0, tx],
         [0, 1, ty],
         [0, 0, 1]]
    
    /* tx, ty are typically positive to shift negative coordinates */
  
  STEP 2: Compose transformation
    H_final = T @ H
    /* Apply translation after homography */
  
  RETURN H_final
```

## Pseudocode - Warp and Place Images

```
FUNCTION warp_and_place_images(img1, img2, H_final, canvas_size, translation):
  """
  Warp image 1 using homography and place image 2 on canvas
  """
  
  INPUT:
    - img1, img2: Input images
    - H_final: Homography with translation (3×3)
    - canvas_size: (canvas_width, canvas_height)
    - translation: [tx, ty] for image 2 placement
  
  STEP 1: Warp image 1
    result1 = warpPerspective(
      img1,
      H_final,
      canvas_size,
      interpolation=LINEAR,
      border_mode=CONSTANT,  /* Black padding (0, 0, 0) */
      border_value=(0, 0, 0)
    )
    
    /* Output: Image 1 warped and positioned on canvas */
  
  STEP 2: Create canvas for image 2
    result2 = zeros_like(result1)
    /* Initialize with black (0, 0, 0) */
  
  STEP 3: Place image 2 on canvas
    tx, ty = translation
    result2[ty : ty + img2.height, 
            tx : tx + img2.width] = img2
    
    /* Image 2 placed at offset position */
  
  RETURN result1, result2
```

---

# PART 5: OVERLAP DETECTION AND BLENDING

**Objective**: Detect and smoothly blend overlapping regions.

## Pseudocode - Search Black Borders

```
FUNCTION search_black_border_columns(image):
  """
  Find leftmost and rightmost columns that contain non-black pixels
  Identifies the horizontal extent of non-black content
  """
  
  INPUT:
    - image: Image with potential black borders
  
  STEP 1: Get image width
    width = image.shape[1]
  
  STEP 2: Find non-black columns
    non_black_columns = []
    
    FOR column_index FROM 0 TO width:
      /* Check if entire column is black (all values = 0) */
      column_pixels = image[:, column_index, :]
      is_column_all_black = all(pixel == 0 for pixel in column_pixels)
      
      IF NOT is_column_all_black:
        non_black_columns.append(column_index)
  
  STEP 3: Find extent
    IF length(non_black_columns) == 0:
      ERROR: "Image appears to be entirely black"
    
    min_column = minimum(non_black_columns)
    max_column = maximum(non_black_columns)
  
  RETURN [min_column, max_column]
```

## Pseudocode - Create Overlap Mask

```
FUNCTION create_overlap_mask(result1, result2):
  """
  Identify pixels where both images have content (overlap region)
  """
  
  INPUT:
    - result1: Warped image 1
    - result2: Placed image 2
  
  STEP 1: Verify same dimensions
    IF result1.shape != result2.shape:
      ERROR: "Images must have same dimensions"
  
  STEP 2: Create binary masks
    mask1 = result1 != 0
    /* True where result1 has non-black content */
    
    mask2 = result2 != 0
    /* True where result2 has non-black content */
  
  STEP 3: Compute overlap
    overlap_mask = logical_and(mask1, mask2)
    /* True where BOTH have content */
    
    overlap_mask = convert_to_uint8(overlap_mask)
  
  RETURN overlap_mask[:, :, 0]
  /* Return as 2D (use first channel for all) */
```

## Pseudocode - Find Min/Max True Values in Column

```
FUNCTION find_min_max_true_in_column(column_array):
  """
  Find first and last indices where value is True in a column
  """
  
  INPUT:
    - column_array: 1D boolean array
  
  STEP 1: Find all True indices
    true_indices = [index FOR index IN range(length(column_array))
                    WHERE column_array[index] == True]
  
  STEP 2: Find extent
    IF length(true_indices) == 0:
      RETURN None  /* No True values */
    
    min_index = minimum(true_indices)
    max_index = maximum(true_indices)
  
  RETURN [min_index, max_index]
```

## Pseudocode - Compute Gradient Blending Masks

```
FUNCTION compute_gradient_blending_masks(result1, result2, overlap_data, 
                                         start_col, end_col):
  """
  Create smooth blending masks using linear gradient
  Gradually transitions from one image to the other in overlap region
  """
  
  INPUT:
    - result1, result2: Warped images
    - overlap_data: Binary overlap mask (2D)
    - start_col, end_col: Column range of overlap
  
  OUTPUT:
    - gradient_mask1: Blending weight for result1 (0=transparent, 1=opaque)
    - gradient_mask2: Blending weight for result2
  
  STEP 1: Initialize masks
    rows, cols = result1.shape[:2]
    gradient_mask1 = ones((rows, cols, 3), dtype=float32)
    gradient_mask2 = ones((rows, cols, 3), dtype=float32)
  
  STEP 2: Compute blending weights for overlap region
    total_overlap_width = end_col - start_col
    timer = 0
    coefficient = 1.13  /* Brightness correction factor */
    
    FOR column_index FROM start_col TO end_col:
      
      /* Compute blending alpha (0 at start, 1 at end) */
      alpha = timer / total_overlap_width
      
      /* Find overlapping rows in this column */
      column_overlap = overlap_data[:, column_index]
      row_extent = find_min_max_true_in_column(column_overlap)
      
      IF row_extent is not None:
        min_row, max_row = row_extent
        
        /* Apply linear gradient blending */
        gradient_mask1[min_row:max_row+1, column_index, :] = 1 - alpha
        gradient_mask2[min_row:max_row+1, column_index, :] = alpha
        
        /* Apply edge correction for top and bottom */
        gradient_mask1[min_row, column_index, :] = 1 - alpha
        gradient_mask2[min_row, column_index, :] = alpha
        
        gradient_mask1[max_row, column_index, :] = (1 - alpha) * coefficient
        gradient_mask2[max_row, column_index, :] = alpha * coefficient
      
      timer += 1
  
  RETURN gradient_mask1, gradient_mask2
```

## Pseudocode - Blend Images

```
FUNCTION blend_images(result1, result2, gradient_mask1, gradient_mask2):
  """
  Combine images using computed blending masks
  """
  
  INPUT:
    - result1, result2: Warped images
    - gradient_mask1, gradient_mask2: Blending weights
  
  STEP 1: Apply masks and blend
    weighted_img1 = result1 * gradient_mask1
    weighted_img2 = result2 * gradient_mask2
    
    blended = weighted_img1 + weighted_img2
  
  STEP 2: Normalize to valid range
    blended_normalized = normalize(blended, 0, 255, NORM_MINMAX)
  
  STEP 3: Convert to uint8
    blended_final = convert_to_uint8(blended_normalized)
  
  RETURN blended_final
```

## Blending Visualization

```
Column Position:  start_col                      end_col
                      ↓                              ↓
Gradient Alpha:   0.0 →→→→→→→→→→→→→→→→→→→→→→→→→→ 1.0
Mask1 Weight:     1.0 ←←←←←←←←←←←←←←←←←←←←←←←←←← 0.0
Mask2 Weight:     0.0 →→→→→→→→→→→→→→→→→→→→→→→→→→ 1.0

Result:
  Left side (Mask1 heavy):   Mostly image1 color
  Middle (50/50):            Smooth blend
  Right side (Mask2 heavy):  Mostly image2 color
```

---

# PART 6: EVALUATION AND VISUALIZATION

**Objective**: Evaluate stitching quality and visualize results.

## Pseudocode - Visualization Functions

```
FUNCTION plot_blending_masks(gradient_mask1, gradient_mask2):
  """
  Visualize the blending weights used in each channel
  """
  
  INPUT:
    - gradient_mask1, gradient_mask2: 3D mask arrays
  
  CREATE figure with 2 subplots:
    
    SUBPLOT 1:
      IMSHOW gradient_mask1[:, :, 0]
      colormap = 'jet'  /* Blue (0) to Red (1) */
      SET title "Gradient Mask of Image (Left)"
      ADD colorbar
    
    SUBPLOT 2:
      IMSHOW gradient_mask2[:, :, 0]
      colormap = 'jet'
      SET title "Gradient Mask of Image (Right)"
      ADD colorbar
  
  DISPLAY figure
```

## Pseudocode - Display Stitched Image

```
FUNCTION display_stitched_result(stitched_image):
  """
  Show final panoramic image
  """
  
  INPUT:
    - stitched_image: Final blended panorama
  
  CREATE figure:
    IMSHOW stitched_image
    SET title "Stitching Result"
    axis off
  
  DISPLAY figure
```

## Pseudocode - Compare Before/After Preprocessing

```
FUNCTION compare_preprocessing_effects(img1, img2, img2_adjusted):
  """
  Visualize impact of preprocessing on stitching
  """
  
  INPUT:
    - img1: First image
    - img2: Original second image
    - img2_adjusted: After histogram matching
  
  CREATE figure with 3 subplots:
    
    SUBPLOT 1:
      IMSHOW img1
      SET title "Image 1"
    
    SUBPLOT 2:
      IMSHOW img2
      SET title "Original Image 2"
    
    SUBPLOT 3:
      IMSHOW img2_adjusted
      SET title "After Histogram Matching"
  
  DISPLAY figure
  
  /* Visual differences:
     - Color tone more consistent
     - Brightness levels similar
     - Blend seams less noticeable
  */
```

---

# COMPLETE STITCHING PIPELINE

## Pseudocode - Main Stitching Function

```
FUNCTION image_stitching_pipeline(img1, img2):
  """
  Complete end-to-end image stitching
  """
  
  INPUT:
    - img1, img2: Color images in RGB
  
  ╔══════════════════════════════════════════════════════╗
  ║ STEP 1: FEATURE DETECTION                            ║
  ╚══════════════════════════════════════════════════════╝
  
  keypoints1, descriptors1 = detect_sift_features(img1)
  keypoints2, descriptors2 = detect_sift_features(img2)
  
  PRINT f"Image 1 keypoints: {len(keypoints1)}"
  PRINT f"Image 2 keypoints: {len(keypoints2)}"
  
  ╔══════════════════════════════════════════════════════╗
  ║ STEP 2: FEATURE MATCHING                             ║
  ╚══════════════════════════════════════════════════════╝
  
  raw_matches = match_features(descriptors1, descriptors2)
  good_matches = filter_matches_by_ratio_test(raw_matches, ratio=0.7)
  
  PRINT f"Good matches: {len(good_matches)}"
  
  IF len(good_matches) < 4:
    ERROR: "Insufficient matches for homography computation"
  
  ╔══════════════════════════════════════════════════════╗
  ║ STEP 3: GEOMETRIC ALIGNMENT                          ║
  ╚══════════════════════════════════════════════════════╝
  
  points1, points2 = extract_matched_points(
    keypoints1, keypoints2, good_matches
  )
  
  H, inlier_mask = compute_homography_ransac(
    points1, points2, threshold=5.0
  )
  
  mean_error = compute_reprojection_error(points1, points2, H)
  PRINT f"Reprojection error: {mean_error:.4f} pixels"
  
  ╔══════════════════════════════════════════════════════╗
  ║ STEP 4: COMPUTE OUTPUT CANVAS                        ║
  ╚══════════════════════════════════════════════════════╝
  
  canvas_size, translation = compute_output_canvas(
    img1.shape, H, img2.shape
  )
  
  H_final = create_homography_with_translation(H, translation)
  
  PRINT f"Output canvas size: {canvas_size}"
  PRINT f"Translation vector: {translation}"
  
  ╔══════════════════════════════════════════════════════╗
  ║ STEP 5: WARP AND PLACE IMAGES                        ║
  ╚══════════════════════════════════════════════════════╝
  
  result1, result2 = warp_and_place_images(
    img1, img2, H_final, canvas_size, translation
  )
  
  ╔══════════════════════════════════════════════════════╗
  ║ STEP 6: DETECT OVERLAP AND BLEND                     ║
  ╚══════════════════════════════════════════════════════╝
  
  overlap_mask = create_overlap_mask(result1, result2)
  
  /* Find horizontal extent of overlap */
  left_border = search_black_border_columns(result1)
  right_border = search_black_border_columns(result2)
  
  blend_data = [left_border[0], right_border[0], 
                left_border[1], right_border[1]]
  blend_data = sort(blend_data)
  
  overlap_start_col = blend_data[1]
  overlap_end_col = blend_data[2]
  
  gradient_mask1, gradient_mask2 = compute_gradient_blending_masks(
    result1, result2, overlap_mask, 
    overlap_start_col, overlap_end_col
  )
  
  blended_panorama = blend_images(
    result1, result2, gradient_mask1, gradient_mask2
  )
  
  ╔══════════════════════════════════════════════════════╗
  ║ STEP 7: VISUALIZATION                                ║
  ╚══════════════════════════════════════════════════════╝
  
  plot_blending_masks(gradient_mask1, gradient_mask2)
  display_stitched_result(blended_panorama)
  
  RETURN blended_panorama, gradient_mask1, gradient_mask2
```

---

# DESIGN DECISIONS AND JUSTIFICATIONS

## 1. SIFT Features (vs ORB, AKAZE, etc.)

```
Why SIFT?
  ✓ Highly distinctive and stable across scale/rotation
  ✓ Works well with overlapping images at various angles
  ✓ Robust to lighting and viewing changes
  ✓ Well-tested for image stitching applications

Trade-offs:
  ✗ Slower than ORB/AKAZE (but accuracy matters more for stitching)
  ✗ Patented algorithm (licensing considerations)
  ~ Not real-time suitable
```

## 2. Brute Force Matching (vs FLANN)

```
Why BFMatcher with kNN?
  ✓ Simple and reliable for stitching
  ✓ Allows Lowe's ratio test for quality filtering
  ✓ Suitable for moderate image sizes
  ✓ Deterministic results

Trade-offs:
  ✗ Slower for very large descriptor sets (O(n²))
  ~ FLANN faster for large datasets but more complex
```

## 3. Lowe's Ratio Test

```
Why 0.7 threshold?
  ✓ Removes ~50% of false matches
  ✓ 0.7 = standard value (good empirical choice)
  ✓ Balances precision vs recall
  ✓ Critical for robust homography estimation

Effect of different thresholds:
  0.5: Very strict, fewer matches but higher confidence
  0.7: Standard, good balance
  0.9: Permissive, more matches but more outliers
```

## 4. RANSAC for Homography

```
Why RANSAC?
  ✓ Robust to outliers in matched points
  ✓ Handles failed matches naturally
  ✓ Provides inlier/outlier classification
  ✓ Well-established for geometric estimation

Threshold = 5.0 pixels:
  ✓ Reasonable tolerance for reprojection error
  ✓ Higher than typical noise but catches misalignments
  ~ Can adjust based on image resolution and quality
```

## 5. Histogram Matching Preprocessing

```
Why histogram matching?
  ✓ Corrects exposure differences
  ✓ Matches color temperature/tone
  ✓ Makes blending seams invisible
  ✓ Simple and effective

Impact visible in:
  - Color continuity across seam
  - No sudden brightness jumps
  - Natural-looking blend transitions
  - Higher subjective quality
```

## 6. Linear Gradient Blending

```
Why gradient blending?
  ✓ Smooth transition between images
  ✓ Avoids hard boundaries in overlap
  ✓ Perceptually pleasing results
  ✓ Computationally efficient

Alternative: Alpha blending
  ~ Fixed alpha: Equal weights
  ~ Problematic: Visible discontinuities
  ~ Gradient: Variable weights (better)

Alternative: Multi-band blending
  + Better for edges and textures
  - More complex
  - Overkill for simple overlaps
```

---

# EVALUATION METRICS

## Reprojection Error

```
Metric: Mean pixel distance between detected and projected points
Formula: E = (1/N) * Σ ||projected_i - detected_i||₂

Interpretation:
  < 0.5 px: Excellent alignment
  0.5-1.5 px: Good alignment  
  1.5-3.0 px: Acceptable
  > 3.0 px: Poor alignment
  
Improvement strategies:
  - Use more calibration images
  - Better feature detection
  - Stricter ratio test threshold
  - Increase RANSAC iterations
```

## Visual Quality Assessment

```
Artifacts to watch for:
  
  1. Ghosting
     - Blurred/transparent effects
     - Caused by misalignment
     - Fix: Tighter homography threshold
  
  2. Seam Visibility
     - Visible line at blend boundary
     - Caused by exposure mismatch
     - Fix: Better histogram matching
  
  3. Warping Distortions
     - Unnatural perspective
     - Caused by bad feature matching
     - Fix: More/better features
  
  4. Black Borders
     - Unused canvas areas
     - Usually acceptable
     - Can crop if needed
```

---

# COMMON CHALLENGES AND SOLUTIONS

| Challenge | Cause | Solution |
|-----------|-------|----------|
| Few matches | Weak features, poor overlap | Use better lighting, increase overlap |
| Bad alignment | Outliers not removed | Lower RANSAC threshold or use stricter ratio test |
| Visible seam | Exposure mismatch | Apply histogram matching |
| Ghosting | Misalignment in overlap | Verify homography accuracy |
| High error | Incorrect homography | Check feature quality and quantity |
| Slow stitching | Complex images | Use downsampled versions for alignment |

---

# REFERENCES

- SIFT (Scale-Invariant Feature Transform): https://en.wikipedia.org/wiki/Scale-invariant_feature_transform
- RANSAC: https://en.wikipedia.org/wiki/Random_sample_consensus
- Image Stitching: https://docs.opencv.org/master/d1/d46/group__stitching.html
- Homography: https://en.wikipedia.org/wiki/Homography
- Histogram Matching: https://scikit-image.org/docs/stable/api/skimage.exposure.html#match-histograms
- Lowe's Ratio Test: https://www.cs.ubc.ca/~lowe/papers/ijcv04.pdf
