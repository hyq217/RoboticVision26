# Lab 9: Depth Estimation using Stereo Vision - Pseudocode

## Overview
Lab 9 focuses on stereo vision—estimating 3D depth from multiple image viewpoints. The lab uses Semi-Global Block Matching (SGBM) to compute disparity maps from stereo image pairs, evaluates depth accuracy against ground truth, and synthesizes novel views through depth-based reprojection.

---

# STEREO VISION WORKFLOW

```
INPUT: Three calibrated images (a, b, c), intrinsic matrix K, ground truth depth maps

STEP 1: Load data
  ├─ Load three images and their ground truth depth
  ├─ Load calibrated intrinsic matrix K
  └─ Define baseline distance for stereo pair

STEP 2: Estimate depth from stereo pairs
  ├─ Pair 1: Images b-c (estimate depth at b's viewpoint)
  ├─ Pair 2: Images b-a (estimate depth at b's viewpoint)
  ├─ Pair 3: Images a-c (estimate depth at a's viewpoint)
  └─ Use SGBM algorithm for all pairs

STEP 3: Evaluate depth accuracy
  ├─ Quantitative: Compute MAE, RMSE vs ground truth
  ├─ Select best stereo pair (lowest error)
  └─ Report accuracy metrics

STEP 4: Qualitative evaluation
  ├─ Compute L1 difference map (estimated depth vs ground truth)
  ├─ Reproject image using estimated depth to alternate viewpoint
  ├─ Visualize both evaluation metrics
  └─ Compare reprojected view with original

OUTPUT: Depth maps, error metrics, L1 difference, reprojected images
```

---

# PART 1: CAMERA CALIBRATION AND DATA LOADING

**Objective**: Load calibrated camera parameters and stereo image pairs.

## Background: Camera Intrinsics

```
Intrinsic matrix K (camera calibration parameters):
  K = [fx  0  cx]
      [0  fy  cy]
      [0   0   1]

Where:
  fx, fy = focal length in pixels (x and y directions)
  cx, cy = principal point (image center) in pixels
  
In this lab:
  K = [600   0  600]
      [  0 600  300]
      [  0   0    1]
  
Interpretation:
  - Focal length: 600 pixels (both x and y)
  - Image center: (600, 300) pixels
  - Square pixels assumed (fx = fy)
```

## Pseudocode - Camera Setup

```
FUNCTION setup_camera_parameters():
  """
  Initialize camera intrinsic matrix and stereo baseline
  """
  
  OUTPUT:
    - K: 3×3 intrinsic matrix
    - BASELINE: Baseline distance between stereo cameras
  
  K = [600.0,   0.0, 600.0]
      [  0.0, 600.0, 300.0]
      [  0.0,   0.0,   1.0]
  
  BASELINE = 1.0
  /* Baseline in metric units (typically mm or cm)
     Set to 1.0 for relative depth estimation
     (absolute scale depends on true baseline) */
  
  RETURN K, BASELINE
```

## Pseudocode - Image Loading

```
FUNCTION read_grayscale(filepath):
  """
  Load and convert image to grayscale float32
  """
  
  INPUT: filepath to image file
  
  IF file exists:
    image_raw = read_image_file(filepath, mode=GRAYSCALE)
    image_float = convert_to_float32(image_raw)
    RETURN image_float
  ELSE:
    PRINT warning about missing file
    RETURN None

FUNCTION read_color(filepath):
  """
  Load image in color (BGR format)
  """
  
  INPUT: filepath to image file
  
  IF file exists:
    image = read_image_file(filepath, mode=COLOR)
    RETURN image  /* Format: BGR (OpenCV convention) */
  ELSE:
    PRINT warning about missing file
    RETURN None

FUNCTION load_stereo_data(image_paths, gt_depth_paths):
  """
  Load all images and ground truth depths
  """
  
  INPUT:
    - image_paths: List of 3 image file paths [img_a, img_b, img_c]
    - gt_depth_paths: List of 3 ground truth depth paths
  
  OUTPUT:
    - images: Dictionary of loaded images
    - gt_depths: Dictionary of loaded ground truth depths
  
  INITIALIZATION:
    images = {}
    gt_depths = {}
  
  FOR each image path:
    images[name] = read_color(image_path)
  
  FOR each ground truth path:
    gt_depths[name] = read_grayscale(gt_depth_path)
  
  RETURN images, gt_depths
```

---

# PART 2: DEPTH NORMALIZATION

**Objective**: Normalize depth maps to [0, 1] range for comparison.

## Pseudocode - Normalization

```
FUNCTION normalize_depth(depth_map):
  """
  Normalize depth to [0, 1] range for visualization and comparison
  """
  
  INPUT:
    - depth_map: H×W array of depth values
  
  OUTPUT:
    - normalized: H×W array, values in [0, 1]
  
  STEP 1: Check validity
    IF depth_map is None:
      RETURN None
  
  STEP 2: Get min and max
    d_min = minimum(depth_map)
    d_max = maximum(depth_map)
  
  STEP 3: Handle flat maps (no variation)
    IF (d_max - d_min) < 1e-8:
      /* All values nearly identical, no depth variation */
      RETURN zeros_like(depth_map)
  
  STEP 4: Normalize to [0, 1]
    normalized = (depth_map - d_min) / (d_max - d_min)
    
  RETURN normalized
```

**Purpose of Normalization**:
```
Why normalize?
  1. Ground truth depth maps may have different scale/range
  2. Estimated depths depend on baseline and focal length
  3. Normalization makes comparison scale-invariant
  4. Enables visualizing on standardized colormap
  
When to use?
  ✓ For error comparison between different stereo pairs
  ✓ For visualization with colormaps
  ✓ For qualitative evaluation (L1 difference maps)
  
When NOT to use?
  ✗ When computing real-world 3D coordinates
  ✗ When scale information is important
```

---

# PART 3: STEREO DEPTH ESTIMATION (SGBM)

**Objective**: Estimate depth from a stereo image pair using Semi-Global Block Matching.

## Background: Stereo Vision and Disparity

```
Stereo matching principle:
  1. Two cameras capture same scene from different positions
  2. For a point P in 3D space:
     - It projects to (u1, v) in left image
     - It projects to (u2, v) in right image
     - Disparity d = u1 - u2 (horizontal displacement)
  
  3. Depth from disparity:
     z = (f × baseline) / d
     
     Where:
       f = focal length (K[0,0])
       baseline = distance between cameras
       d = disparity
       z = depth

Disparity map:
  - Same size as input images
  - Each pixel contains disparity value (in 1/16 pixel units)
  - Convert to depth: depth = f × baseline / disparity
```

## Pseudocode - SGBM Stereo Matching

```
FUNCTION stereo_depth_estimation(left_image_path, right_image_path):
  """
  Estimate depth from stereo image pair using SGBM
  (Semi-Global Block Matching)
  """
  
  INPUT:
    - left_image_path: Path to left image
    - right_image_path: Path to right image
  
  OUTPUT:
    - depth: H×W depth map (metric units)
  
  STEP 1: Load and preprocess images
    left_color = read_color(left_image_path)
    right_color = read_color(right_image_path)
    
    IF either is None:
      RETURN None
    
    /* Convert to grayscale for matching */
    left_gray = convert_BGR_to_grayscale(left_color)
    right_gray = convert_BGR_to_grayscale(right_color)
  
  STEP 2: Setup SGBM parameters
    min_disparity = 0
    /* Minimum disparity to search for */
    
    num_disparities = 128
    /* Range of disparity search: [min_disparity, min_disparity + num_disparities]
       Must be divisible by 16 (SGBM requirement)
       Larger = larger depth range, slower computation */
    
    block_size = 5
    /* Window size for block matching [5×5 pixels]
       Larger block = smoother but loses detail
       Smaller block = preserves detail but more noise */
    
    P1 = 8 × 1 × (block_size²)
    P2 = 32 × 1 × (block_size²)
    /* Smoothness penalties for semi-global optimization
       P1: penalty for disparity change of ±1
       P2: penalty for larger disparity changes
       P2 > P1 encourages smooth disparity (important!)
       
       Higher P1, P2 = smoother results
       Lower P1, P2 = more faithful to image features */
    
    disp12_max_diff = 1
    /* Maximum allowed difference in left-right consistency check
       Lower = stricter consistency (discards unreliable matches) */
    
    uniqueness_ratio = 5
    /* Margin to declare unique match (in %)
       Match is valid only if best_cost significantly < second_best_cost */
    
    speckle_window_size = 100
    /* Window size for speckle filtering
       Removes small isolated regions (noise) */
    
    speckle_range = 32
    /* Range for speckle filtering
       Disparity variation within window must be < speckle_range */
  
  STEP 3: Create SGBM matcher
    sgbm_matcher = create_SGBM_matcher(
      minDisparity=min_disparity,
      numDisparities=num_disparities,
      blockSize=block_size,
      P1=P1,
      P2=P2,
      disp12MaxDiff=disp12_max_diff,
      uniquenessRatio=uniqueness_ratio,
      speckleWindowSize=speckle_window_size,
      speckleRange=speckle_range
    )
  
  STEP 4: Compute disparity map
    disparity_raw = sgbm_matcher.compute(left_gray, right_gray)
    
    /* disparity_raw is in 1/16 pixel units (OpenCV convention)
       Need to convert to pixel units for depth calculation */
  
  STEP 5: Convert disparity to pixel units
    disparity = convert_to_float32(disparity_raw) / 16.0
    
    /* Now disparity is in pixel units */
  
  STEP 6: Avoid division by zero
    disparity[disparity < 1.0] = 1.0
    /* Set very small disparities to 1.0
       (Very small disparity → very large depth → unreliable) */
  
  STEP 7: Convert disparity to depth
    focal_length = K[0, 0]
    /* fx from intrinsic matrix */
    
    depth = (focal_length × BASELINE) / disparity
    
    /* This gives metric depth where units depend on baseline units */
  
  RETURN depth
```

## SGBM Algorithm Details

```
Semi-Global Block Matching algorithm flow:

INPUT: Left grayscale image, Right grayscale image, parameters

STEP 1: Cost volume computation
  FOR each disparity d in [min_disp, min_disp + num_disp]:
    FOR each pixel (x, y):
      Extract block at (x, y) from left image
      Extract block at (x-d, y) from right image
      Compute cost (e.g., SAD - Sum of Absolute Differences)
      cost_volume[y, x, d] = cost
  
  Result: Cost volume of shape (H, W, num_disparities)

STEP 2: Semi-global optimization
  /* Find disparity that minimizes total cost while maintaining smoothness */
  
  FOR each pixel and direction (8 directions):
    Accumulate cost considering:
      - Data cost (matching cost)
      - Smoothness penalty (encourages similar disparities in neighbors)
  
  /* Semi-global: Combines local matching with global smoothness */

STEP 3: Winner-take-all
  FOR each pixel (x, y):
    disparity[x, y] = argmin(accumulated_cost[x, y, :])
  
  Result: Single disparity map (not probabilistic)

STEP 4: Post-processing
  - Left-right consistency check
  - Speckle filtering (remove isolated regions)
  - Occlusion handling

OUTPUT: Disparity map (integer values)
```

---

# PART 4: QUANTITATIVE EVALUATION

**Objective**: Compute error metrics comparing estimated depth to ground truth.

## Pseudocode - Error Metrics

```
FUNCTION compute_error_metrics(gt_depth, estimated_depth, pair_name=""):
  """
  Compute MAE and RMSE between ground truth and estimated depth
  """
  
  INPUT:
    - gt_depth: H×W ground truth depth map
    - estimated_depth: H×W estimated depth map
    - pair_name: Name for this comparison (for reporting)
  
  OUTPUT:
    - mae: Mean Absolute Error
    - rmse: Root Mean Squared Error
  
  STEP 1: Validation
    IF gt_depth is None OR estimated_depth is None:
      PRINT f"Skip evaluation: missing data for {pair_name}"
      RETURN None, None
  
  STEP 2: Ensure same size
    IF gt_depth.shape ≠ estimated_depth.shape:
      estimated_depth = resize(estimated_depth, (gt_depth.width, gt_depth.height))
  
  STEP 3: Flatten to 1D arrays
    gt_flat = flatten(gt_depth)
    est_flat = flatten(estimated_depth)
  
  STEP 4: Compute absolute errors
    abs_errors = abs(gt_flat - est_flat)
  
  STEP 5: Compute MAE (Mean Absolute Error)
    mae = mean(abs_errors)
    /* Average pixel-wise error magnitude
       Interpretation: On average, estimated depth is off by mae units */
  
  STEP 6: Compute RMSE (Root Mean Squared Error)
    squared_errors = (gt_flat - est_flat)²
    mse = mean(squared_errors)
    rmse = sqrt(mse)
    /* Gives more weight to large errors
       Interpretation: RMS error magnitude (in same units as depth) */
  
  STEP 7: Report results
    PRINT f"{pair_name}:"
    PRINT f"  MAE:  {mae:.4f}"
    PRINT f"  RMSE: {rmse:.4f}"
  
  RETURN mae, rmse
```

## Pseudocode - Evaluate Multiple Stereo Pairs

```
FUNCTION evaluate_all_stereo_pairs(image_paths, gt_depth_maps):
  """
  Evaluate depth from all three stereo pair combinations
  """
  
  INPUT:
    - image_paths: {a, b, c} image file paths
    - gt_depth_maps: {a, b, c} ground truth depth maps
  
  OUTPUT:
    - results: Dictionary with error metrics and depth maps
    - best_pair: Which pair had lowest error
  
  INITIALIZATION:
    results = {}
  
  /* Stereo pair 1: b and c, estimate depth at b's viewpoint */
  SECTION: Pair B-C
    depth_bc = stereo_depth_estimation(image_paths['b'], image_paths['c'])
    norm_depth_bc = normalize(depth_bc)
    norm_gt_b = normalize(gt_depth_maps['b'])
    
    mae_bc, rmse_bc = compute_error_metrics(norm_gt_b, norm_depth_bc, "Pair BC vs GT(b)")
    
    results['BC'] = {
      'depth': depth_bc,
      'normalized': norm_depth_bc,
      'gt': norm_gt_b,
      'mae': mae_bc,
      'rmse': rmse_bc,
      'reference_image': image_paths['b']
    }
  
  /* Stereo pair 2: b and a, estimate depth at b's viewpoint */
  SECTION: Pair B-A
    depth_ba = stereo_depth_estimation(image_paths['b'], image_paths['a'])
    norm_depth_ba = normalize(depth_ba)
    
    mae_ba, rmse_ba = compute_error_metrics(norm_gt_b, norm_depth_ba, "Pair BA vs GT(b)")
    
    results['BA'] = {
      'depth': depth_ba,
      'normalized': norm_depth_ba,
      'gt': norm_gt_b,
      'mae': mae_ba,
      'rmse': rmse_ba,
      'reference_image': image_paths['b']
    }
  
  /* Stereo pair 3: a and c, estimate depth at a's viewpoint */
  SECTION: Pair A-C
    depth_ac = stereo_depth_estimation(image_paths['a'], image_paths['c'])
    norm_depth_ac = normalize(depth_ac)
    norm_gt_a = normalize(gt_depth_maps['a'])
    
    mae_ac, rmse_ac = compute_error_metrics(norm_gt_a, norm_depth_ac, "Pair AC vs GT(a)")
    
    results['AC'] = {
      'depth': depth_ac,
      'normalized': norm_depth_ac,
      'gt': norm_gt_a,
      'mae': mae_ac,
      'rmse': rmse_ac,
      'reference_image': image_paths['a']
    }
  
  /* Find best pair (lowest MAE) */
  STEP: Select best pair
    best_pair = argmin(results[pair]['mae'] for all pairs)
    
    PRINT f"\nBest stereo pair: {best_pair}"
  
  RETURN results, best_pair
```

---

# PART 5: QUALITATIVE EVALUATION - L1 DIFFERENCE MAP

**Objective**: Visualize depth estimation error as a color map.

## Pseudocode - L1 Error Map

```
FUNCTION compute_l1_difference_map(gt_normalized_depth, estimated_normalized_depth):
  """
  Compute pixel-wise L1 (absolute) error between estimated and ground truth depth
  """
  
  INPUT:
    - gt_normalized_depth: H×W ground truth (normalized to [0,1])
    - estimated_normalized_depth: H×W estimated depth (normalized to [0,1])
  
  OUTPUT:
    - l1_map: H×W error map, values in [0, 1]
  
  STEP 1: Compute absolute difference
    l1_map = abs(gt_normalized_depth - estimated_normalized_depth)
  
  STEP 2: Ensure valid range
    l1_map = clip(l1_map, 0, 1)
  
  RETURN l1_map
```

## Interpretation of L1 Difference Map

```
Colormap 'jet' (common for error visualization):
  Dark blue (0): Perfect match (no error)
  Cyan/Light blue: Small error
  Green: Medium error
  Yellow/Red: Large error (poor match)
  
What to look for:
  ✓ Mostly dark/blue: Good depth estimation
  ✓ Errors at boundaries: Normal (occlusion/texture issues)
  ✗ Red/orange regions: Algorithm failed in these areas
  ✗ Systematic patterns: Indicates algorithmic bias

Common failure modes:
  - Textureless regions: Hard to match (high error)
  - Occlusion boundaries: Foreground/background confusion
  - Specular reflections: Confuse block matching
  - Thin structures: Depth uncertainty increases
```

---

# PART 6: QUALITATIVE EVALUATION - VIEW SYNTHESIS

**Objective**: Reproject image to alternative viewpoint using estimated depth.

## Background: 3D Reprojection

```
Goal: Synthesize image from novel camera viewpoint

Process:
  1. Original image: Known camera pose and depth
  2. Reproject 3D points:
     a) Unproject from original image: (u,v) → (X,Y,Z) using depth and K
     b) Transform to new pose: (X,Y,Z) → (X',Y',Z')
     c) Project to new image: (X',Y',Z') → (u',v') using K
  3. Bilinear interpolation: Sample colors from (u',v')
  4. Result: Synthesized view from new camera pose
```

## Pseudocode - Reproject Image

```
FUNCTION reproject_image_to_new_view(image, depth_map, K, transformation_matrix):
  """
  Warp image to alternative viewpoint using estimated depth
  """
  
  INPUT:
    - image: H×W×3 color image to reproject
    - depth_map: H×W depth map (metric units)
    - K: 3×3 intrinsic matrix
    - transformation_matrix: 4×4 transformation from original to new pose
  
  OUTPUT:
    - reprojected: H×W×3 warped image
  
  STEP 1: Create pixel coordinate grid
    (u, v) = meshgrid(0 to width-1, 0 to height-1)
    u_flat = flatten(u)  /* All u-coordinates in single array */
    v_flat = flatten(v)  /* All v-coordinates in single array */
    depth_flat = flatten(depth_map)
  
  STEP 2: Extract camera parameters
    fx = K[0, 0]  /* Focal length x */
    fy = K[1, 1]  /* Focal length y */
    cx = K[0, 2]  /* Principal point x */
    cy = K[1, 2]  /* Principal point y */
  
  STEP 3: Unproject from original image to 3D
    X = (u_flat - cx) × depth_flat / fx
    Y = (v_flat - cy) × depth_flat / fy
    Z = depth_flat
    
    /* (X, Y, Z) = 3D coordinates in camera frame */
  
  STEP 4: Convert to homogeneous coordinates
    ones = array_of_ones(size of u_flat)
    points_homogeneous = [X, Y, Z, ones]  /* 4×N matrix */
  
  STEP 5: Apply transformation to new camera frame
    transformed_points = transformation_matrix @ points_homogeneous
    /* Result: 4×N matrix with transformed coordinates */
  
  STEP 6: Extract transformed 3D coordinates
    X_new = transformed_points[0, :]
    Y_new = transformed_points[1, :]
    Z_new = transformed_points[2, :]
  
  STEP 7: Project to new image using K
    projection = K @ [X_new, Y_new, Z_new]  /* 3×N matrix */
    
    u_proj = projection[0, :]
    v_proj = projection[1, :]
    z_proj = projection[2, :]
  
  STEP 8: Normalize by z (perspective division)
    z_proj[z_proj ≈ 0] = 1e-6  /* Avoid division by zero */
    u_proj = u_proj / z_proj
    v_proj = v_proj / z_proj
  
  STEP 9: Reshape to image coordinates
    u_proj = reshape(u_proj, (height, width))
    v_proj = reshape(v_proj, (height, width))
    
    /* u_proj, v_proj are now H×W grids of target coordinates */
  
  STEP 10: Bilinear interpolation (remapping)
    reprojected = bilinear_remap(
      image,
      u_proj,
      v_proj,
      interpolation='linear',
      border_mode='constant',
      fill_value=0
    )
  
  STEP 11: Handle boundary artifacts
    WHERE z_proj ≤ 0:
      /* Points behind camera - set to black */
      reprojected[i,j] = [0, 0, 0]
  
  RETURN reprojected
```

## Pseudocode - Define Camera Transformation

```
FUNCTION create_rotation_matrix(angle_degrees, axis='y'):
  """
  Create 4×4 transformation matrix for rotation
  """
  
  INPUT:
    - angle_degrees: Rotation angle in degrees
    - axis: 'x', 'y', or 'z' axis to rotate around
  
  OUTPUT:
    - T: 4×4 transformation matrix
  
  STEP 1: Convert to radians
    angle_rad = angle_degrees × π / 180
  
  STEP 2: Create rotation matrix (for Y-axis rotation)
    IF axis == 'y':
      cos_a = cosine(angle_rad)
      sin_a = sine(angle_rad)
      
      R = [cos_a,  0, sin_a,   0]
          [  0,    1,   0,     0]
          [-sin_a, 0, cos_a,   0]
          [  0,    0,   0,     1]
  
  /* Similar for 'x' and 'z' axes */
  
  RETURN R
```

## Visualization of Reprojection

```
FUNCTION visualize_reprojection_results(l1_difference, reprojected_image):
  """
  Display error map and reprojected view side by side
  """
  
  CREATE figure with 1×2 subplots
  
  Subplot 1 (Left):
    Display L1 difference map
    Colormap: 'jet'
    Add colorbar to show error scale
    Title: "L1 Difference (Estimated vs Ground Truth)"
  
  Subplot 2 (Right):
    Display reprojected image
    Colormap: None (RGB image)
    Title: "Reprojected View (15° rotation around Y-axis)"
  
  set_figure_title("Stereo Depth Evaluation Results")
  adjust_layout()
  
  DISPLAY or SAVE figure
```

---

# PART 7: COMPLETE PIPELINE

## Pseudocode - Main Experiment

```
FUNCTION main_depth_estimation_pipeline():
  """
  Complete stereo depth estimation and evaluation workflow
  """
  
  ╔══════════════════════════════════════════════════════════════════╗
  ║ SETUP: Load calibration and data                                 ║
  ╚══════════════════════════════════════════════════════════════════╝
  
  /* Initialize camera parameters */
  K, BASELINE = setup_camera_parameters()
  
  PRINT "Camera Intrinsic Matrix:"
  PRINT K
  PRINT f"Baseline: {BASELINE}"
  
  /* Define image and ground truth paths */
  image_paths = {
    'a': 'task1/a.png',
    'b': 'task1/b.png',
    'c': 'task1/c.png'
  }
  
  gt_paths = {
    'a': 'task1/a_gt_depth.png',
    'b': 'task1/b_gt_depth.png',
    'c': 'task1/c_gt_depth.png'
  }
  
  /* Load images and ground truth */
  images = {}
  gt_depths = {}
  
  FOR each image_name, path IN image_paths:
    images[image_name] = read_color(path)
    gt_depths[image_name] = read_grayscale(gt_paths[image_name])
  
  ╔══════════════════════════════════════════════════════════════════╗
  ║ QUANTITATIVE EVALUATION: Estimate depth and compute errors       ║
  ╚══════════════════════════════════════════════════════════════════╝
  
  PRINT "\n=== DEPTH ESTIMATION FROM STEREO PAIRS ==="
  
  results, best_pair_name = evaluate_all_stereo_pairs(
    image_paths,
    gt_depths
  )
  
  /* Extract best result */
  best_result = results[best_pair_name]
  best_depth = best_result['depth']
  best_depth_norm = best_result['normalized']
  best_gt = best_result['gt']
  best_image_path = best_result['reference_image']
  
  ╔══════════════════════════════════════════════════════════════════╗
  ║ QUALITATIVE EVALUATION 1: L1 Difference Map                      ║
  ╚══════════════════════════════════════════════════════════════════╝
  
  PRINT "\n=== COMPUTING ERROR VISUALIZATION ==="
  
  l1_error_map = compute_l1_difference_map(best_gt, best_depth_norm)
  
  PRINT "L1 error map computed"
  PRINT f"  Mean L1 error: {mean(l1_error_map):.4f}"
  PRINT f"  Max L1 error: {max(l1_error_map):.4f}"
  
  ╔══════════════════════════════════════════════════════════════════╗
  ║ QUALITATIVE EVALUATION 2: View Synthesis via Reprojection        ║
  ╚══════════════════════════════════════════════════════════════════╝
  
  PRINT "\n=== REPROJECTING TO NOVEL VIEWPOINT ==="
  
  /* Load reference image in color */
  reference_image_color = read_color(best_image_path)
  
  /* Define camera transformation: 15° rotation around Y-axis */
  angle_deg = 15.0
  transformation = create_rotation_matrix(angle_deg, axis='y')
  
  PRINT f"Camera pose: {angle_deg}° rotation around Y-axis"
  
  /* Reproject image to new viewpoint */
  reprojected_view = reproject_image_to_new_view(
    reference_image_color,
    best_depth,
    K,
    transformation
  )
  
  PRINT "Image reprojected to new viewpoint"
  
  ╔══════════════════════════════════════════════════════════════════╗
  ║ VISUALIZATION: Display all results                                ║
  ╚══════════════════════════════════════════════════════════════════╝
  
  PRINT "\n=== GENERATING VISUALIZATIONS ==="
  
  /* Create comparison figure */
  CREATE_FIGURE(figsize=(12, 5))
  SET_TITLE("Stereo Depth Estimation: Evaluation Results")
  
  /* Subplot 1: L1 Difference Map */
  SUBPLOT(1, 2, 1)
  imshow(l1_error_map, colormap='jet')
  title("L1 Difference (Estimated vs GT)")
  add_colorbar(label="Absolute Error")
  axis off
  
  /* Subplot 2: Reprojected View */
  SUBPLOT(1, 2, 2)
  converted_image = convert_BGR_to_RGB(reprojected_view)
  imshow(converted_image)
  title("Reprojected View (15° rotation)")
  axis off
  
  tight_layout()
  SHOW_OR_SAVE_FIGURE("stereo_evaluation.png")
  
  ╔══════════════════════════════════════════════════════════════════╗
  ║ SUMMARY: Print final report                                      ║
  ╚══════════════════════════════════════════════════════════════════╝
  
  PRINT "\n=== FINAL REPORT ==="
  PRINT f"Best stereo pair: {best_pair_name}"
  PRINT f"MAE (normalized): {best_result['mae']:.4f}"
  PRINT f"RMSE (normalized): {best_result['rmse']:.4f}"
  PRINT "\nEvaluation complete. Results saved."
```

---

# SGBM ALGORITHM PARAMETERS GUIDE

## Parameter Selection Strategy

```
Parameter          Range     Default  Effect
──────────────────────────────────────────────────────────────
blockSize          5-21      5        ↑ Size: smoother but loses detail
numDisparities     16-256    128      ↑ Size: larger depth range, slower
P1, P2            0-1000     default  ↑ Value: smoother surface
uniqueness_ratio  0-100%     5        ↑ Value: discard weak matches
speckle_range     0-256      32       ↑ Value: tolerate more noise
speckle_window    10-200     100      ↑ Size: more aggressive filtering
```

## Tuning Recommendations

```
For SMOOTH, LOW-NOISE scenes:
  blockSize = 5-7 (preserve detail)
  P1, P2 = normal
  uniqueness_ratio = 5-10 (strict matching)

For TEXTURED scenes with NOISE:
  blockSize = 9-15 (smooth over noise)
  P1, P2 = increase by 2-4× (strong smoothing)
  uniqueness_ratio = 1-3 (accept more matches)

For REAL-WORLD, CHALLENGING scenes:
  blockSize = 11-21 (aggressive smoothing)
  P1, P2 = max out (very strong smoothing)
  speckle_range = increase (tolerate more noise)
```

---

# COMMON ISSUES AND SOLUTIONS

```
Issue                      Cause                 Solution
────────────────────────────────────────────────────────────
Noisy depth map           Block size too small   Increase blockSize
Depth "holes"             Occlusion/texture      Increase speckleWindowSize
Overly smooth result      P1, P2 too high        Decrease smoothness penalties
Poor at boundaries        Matching fails         Use larger blockSize
No depth variation        Rectification wrong    Check image alignment
One eye dominant         Focal length mismatch  Verify intrinsics K
Disparity striping       Line artifacts         Reduce P2/P1 ratio
```

---

# ERROR METRIC INTERPRETATION

```
MAE (Mean Absolute Error):
  - Average magnitude of errors
  - Same units as depth
  - Example: MAE=0.05 on [0,1] scale = 5% average error
  - Use for: Easy-to-understand metric, less sensitive to outliers

RMSE (Root Mean Squared Error):
  - RMS of error values
  - More sensitive to large errors than MAE
  - Example: RMSE=0.07 = large errors are present
  - Use for: Penalize large outliers, statistical analysis

Typical values for good estimation:
  MAE < 0.05 (on normalized scale)
  RMSE < 0.1 (on normalized scale)
  
Typical values for poor estimation:
  MAE > 0.15
  RMSE > 0.25
```

---

# DEPTH REPROJECTION - WHAT TO EXPECT

```
Good reprojection indicators:
  ✓ Objects in correct position
  ✓ Occlusions handled correctly (foreground occludes background)
  ✓ Smooth transitions
  ✓ Few holes/artifacts

Poor reprojection indicators:
  ✗ Ghosting (doubled edges, blur)
  ✗ Holes/black regions
  ✗ Distorted/warped geometry
  ✗ Flickering or artifacts

Why artifacts occur:
  1. Depth inaccuracy
     - Smooth surfaces estimated incorrectly
     - Boundaries have high uncertainty
  
  2. Occlusion mismatch
     - What's visible in new view but was occluded in original
     - Filled with background/interpolation
  
  3. Texture aliasing
     - Very detailed areas may alias or blur
  
  4. Temporal artifacts
     - In video: different artifacts per frame
```

---

# PERFORMANCE METRICS

## Computational Complexity

```
Method              Time Complexity    Space
─────────────────────────────────────────────────
SGBM computation    O(HW × num_disp)   O(HW × num_disp)
Post-processing     O(HW)              O(HW)
Reprojection        O(HW)              O(HW)

For typical image (640×480, 128 disparities):
  SGBM: ~100-500 ms on modern GPU
        ~1-5 seconds on CPU
  Full pipeline: ~500 ms - 5 seconds
```

## Accuracy vs Computational Cost Trade-off

```
Higher accuracy (slower):
  ✓ Larger blockSize
  ✓ Higher P1, P2
  ✓ Higher uniqueness_ratio
  ✗ 2-3× slower
  
Faster computation (lower accuracy):
  ✓ Smaller blockSize
  ✓ Lower P1, P2
  ✓ Lower uniqueness_ratio
  ✗ Noisier result
```

---

# COMPARISON TABLE: STEREO PAIRS

```
Stereo Pair    Baseline      Angular Offset    Typical Use
─────────────────────────────────────────────────────────
B-C            Medium        ~30-45°           Standard binocular
B-A            Medium        ~30-45°           Alternative view
A-C            Large         ~60-90°           Large baseline
                                               (wide stereo baseline)

Larger baseline:
  ✓ Better depth resolution (finer disparity differences)
  ✗ Larger occluded regions
  ✗ Harder matching (texture misalignment)
  
Smaller baseline:
  ✓ Easier to match (texture similarity)
  ✗ Poorer depth resolution
  ✓ Fewer occlusions
```

---

# REFERENCES

- Stereo Vision: https://en.wikipedia.org/wiki/Stereo_vision
- SGBM Algorithm: https://arxiv.org/abs/2012.08954
- Disparity to Depth: https://docs.opencv.org/master/dd/d53/tutorial_py_depthmap.html
- View Synthesis: https://en.wikipedia.org/wiki/View_synthesis
- Camera Intrinsics: https://en.wikipedia.org/wiki/Camera_matrix
