# Lab 8: Photometric Stereo - Pseudocode

## Overview
Lab 8 focuses on photometric stereo—reconstructing 3D surface shape from multiple images taken under different lighting conditions. The lab covers image rendering, gradient extraction, depth reconstruction, and error analysis.

---

# PHOTOMETRIC STEREO WORKFLOW

```
INPUT: Normal map, Albedo map, 12 lighting directions

STEP 1: Render images
  ├─ For each of 12 light directions:
  │  ├─ Compute Lambertian shading: intensity = n · l
  │  ├─ Apply albedo: rendered = albedo × intensity
  │  └─ Store rendered image
  └─ Visualize all 12 rendered images

STEP 2: Extract gradients
  ├─ From normal map: extract nx, ny, nz components
  ├─ Compute: p = -nx/nz, q = -ny/nz
  └─ Gradient fields represent surface slope

STEP 3: Reconstruct depth
  ├─ Simple Integration: Path-based accumulation
  ├─ Global Least-Squares: FFT-based Poisson solver
  └─ Poisson Integration: Jacobi iteration solver

STEP 4: Analyze robustness
  ├─ Add Gaussian noise to gradients
  ├─ Reconstruct depth with noisy gradients
  ├─ Compare reconstruction accuracy
  └─ Identify most robust method

OUTPUT: Depth maps, visualizations, error analysis
```

---

# PART 1: DATA LOADING

**Objective**: Load calibrated normals, albedo, and lighting matrix from files.

## Pseudocode - Data Loading

```
FUNCTION load_data():
  """
  Load necessary data for photometric stereo:
  - Lighting directions (12 distinct directions)
  - Albedo map (surface reflectivity)
  - Normal map (surface orientation)
  """
  
  OUTPUT:
    - normal_map: H×W×3 array, normals in [-1, 1]
    - albedo_map: H×W array, values in [0, 1]
    - lighting_matrix: 12×3 array, each row = light direction
  
  STEP 1: Load lighting matrix from YAML file
    fs = open_file_storage('files/LightMatrix.yml', READ_MODE)
    lighting_matrix = fs.get_node('Lights').extract_matrix()
    fs.close()
    
    /* Result: 12×3 matrix with lighting directions */
    /* Each row: (lx, ly, lz) - normalized direction */
  
  STEP 2: Load albedo map
    albedo_raw = read_image('files/albedo.png', GRAYSCALE)
    /* Typically 8-bit: values in [0, 255] */
    
    albedo_map = convert_to_float32(albedo_raw)
    albedo_map = albedo_map / 255.0
    /* Normalize to [0, 1] */
  
  STEP 3: Load normal map
    normal_raw = read_image('files/normal_normalized.png', COLOR)
    /* RGB image: values in [0, 255] */
    
    normal_map = convert_to_float32(normal_raw)
    normal_map = normal_map / 255.0
    /* Initial range: [0, 1] */
    
    normal_map = normal_map * 2.0 - 1.0
    /* Remap to [-1, 1] */
    
    /* Now each pixel has (nx, ny, nz) in [-1, 1] */
  
  STEP 4: Verify normalization (optional)
    FOR each normal vector n:
      length = sqrt(nx² + ny² + nz²)
      IF length ≠ 1.0:
        PRINT "Warning: Normal not unit length"
        PRINT "Consider renormalizing"
  
  RETURN normal_map, albedo_map, lighting_matrix
```

## Data Format

```
Lighting matrix (LightMatrix.yml):
  Lights = [[l1x, l1y, l1z],    Light 1 direction
            [l2x, l2y, l2z],    Light 2 direction
            ...                 ...
            [l12x, l12y, l12z]] Light 12 direction

Normal map (normal_normalized.png):
  - RGB image: R=nx, G=ny, B=nz
  - Range after conversion: [-1, 1]
  - Should be unit vectors: ||(nx, ny, nz)|| = 1

Albedo map (albedo.png):
  - Grayscale image
  - Range after normalization: [0, 1]
  - Higher values = more reflective
```

---

# PART 2: LAMBERTIAN RENDERING

**Objective**: Generate 12 synthetic images using Lambertian shading model.

## Background: Lambertian Shading

```
Intensity = max(0, n · l)

Where:
  n = (nx, ny, nz): Surface normal (unit vector)
  l = (lx, ly, lz): Light direction (unit vector)
  n · l = dot product = cosine of angle between normal and light
  max(0, ·) = clamp to non-negative (no backlit regions)

Final rendered pixel:
  I = ρ × max(0, n · l)
  
Where:
  ρ = albedo (surface reflectivity)
  I = rendered intensity [0, 1]
```

## Pseudocode - Rendering Function

```
FUNCTION render_image(normal_map, albedo_map, light_direction):
  """
  Render one image under a single light direction using Lambertian model
  """
  
  INPUT:
    - normal_map: H×W×3 array of normals
    - albedo_map: H×W array of albedo values
    - light_direction: 3D vector (lx, ly, lz) - unit length
  
  OUTPUT:
    - rendered_image: H×W grayscale image [0, 1]
  
  STEP 1: Compute dot product n · l
    dot_product = zeros(height, width)
    
    FOR each pixel (i, j):
      normal = [normal_map[i, j, 0],
                normal_map[i, j, 1],
                normal_map[i, j, 2]]
      
      dot_product[i, j] = sum(normal * light_direction)
      /* = nx*lx + ny*ly + nz*lz */
  
  STEP 2: Apply Lambertian clamping
    intensity = maximum(dot_product, 0)
    /* Clamp negative values to 0 (no backlit light) */
  
  STEP 3: Apply albedo
    rendered_image = albedo_map * intensity
    /* Multiply each intensity by surface reflectivity */
  
  RETURN rendered_image
```

## Pseudocode - Main Rendering Loop

```
FUNCTION render_all_images(normal_map, albedo_map, lighting_matrix):
  """
  Render 12 images under different lighting conditions
  """
  
  INPUT:
    - normal_map, albedo_map: Data maps
    - lighting_matrix: 12×3 matrix of light directions
  
  OUTPUT:
    - rendered_images: List of 12 H×W images
  
  INITIALIZATION:
    rendered_images = []
  
  MAIN LOOP:
    FOR light_index FROM 0 TO 11:
      
      light_direction = lighting_matrix[light_index]
      /* Extract one row: (lx, ly, lz) */
      
      rendered = render_image(
        normal_map,
        albedo_map,
        light_direction
      )
      
      rendered_images.append(rendered)
  
  RETURN rendered_images
```

## Visualization

```
FUNCTION visualize_rendered_images(rendered_images):
  """
  Display 12 rendered images in 3×4 grid
  """
  
  CREATE figure with 3×4 subplot grid
  
  FOR i FROM 0 TO 11:
    subplot(3, 4, i+1)
    imshow(rendered_images[i], colormap='gray')
    title(f'Light Direction {i+1}')
    axis off
  
  tight_layout()
  save_figure('rendered_images.png')
```

---

# PART 3: GRADIENT EXTRACTION

**Objective**: Convert surface normals to gradient fields p and q.

## Background: Surface Gradients from Normals

```
Mathematical relationship:
  If surface is z = z(x, y), then:
  
  Normal vector: n = (-∂z/∂x, -∂z/∂y, 1) / ||(·)||
  
  After normalization:
    nx = -∂z/∂x / √(1 + (∂z/∂x)² + (∂z/∂y)²)
    ny = -∂z/∂y / √(1 + (∂z/∂x)² + (∂z/∂y)²)
    nz = 1 / √(1 + (∂z/∂x)² + (∂z/∂y)²)
  
  For small slopes (gentle surfaces):
    √(1 + p² + q²) ≈ 1
    
  Approximate relationship (valid for small slopes):
    p ≈ -nx / nz  (gradient in x-direction)
    q ≈ -ny / nz  (gradient in y-direction)
```

## Pseudocode - Gradient Extraction

```
FUNCTION extract_gradients(normal_map):
  """
  Extract surface gradients p, q from normal map
  Using relationship: p = -nx/nz, q = -ny/nz
  """
  
  INPUT:
    - normal_map: H×W×3 array with (nx, ny, nz)
  
  OUTPUT:
    - p: H×W gradient field (∂z/∂x)
    - q: H×W gradient field (∂z/∂y)
  
  STEP 1: Extract normal components
    nx = normal_map[:, :, 0]  /* x-component */
    ny = normal_map[:, :, 1]  /* y-component */
    nz = normal_map[:, :, 2]  /* z-component */
  
  STEP 2: Compute gradient fields
    p = -nx / nz
    q = -ny / nz
    
    /* p > 0: surface slopes down in +x direction
       p < 0: surface slopes up in +x direction
       Similar interpretation for q */
  
  STEP 3: Handle edge cases
    WHERE nz ≈ 0:
      /* Normal is nearly horizontal - undefined gradient */
      p = 0
      q = 0
  
  RETURN p, q
```

## Interpretation

```
Physical meaning:
  p = ∂z/∂x: How much surface height changes per unit in x
  q = ∂z/∂y: How much surface height changes per unit in y

Example:
  p = 0.5 means: for every 1 pixel in x-direction,
                 surface changes by 0.5 units in z-direction
  
  p = -0.2 means: surface slopes upward in +x direction
                  (negative p = upward slope)
```

---

# PART 4: DEPTH RECONSTRUCTION

**Objective**: Integrate gradient fields to recover 3D surface depth.

## Background: Poisson Equation

```
All three integration methods solve (or approximate) the Poisson equation:

  ∇²z = ∂²z/∂x² + ∂²z/∂y² = ∂p/∂x + ∂q/∂y = div(p, q)

Where:
  div(p, q) = divergence of gradient field
  
The goal: Find z(x, y) such that its gradients match p, q
```

---

## Method 1: Simple Path-Based Integration

### Pseudocode

```
FUNCTION simple_integration(p, q):
  """
  Reconstruct depth via direct accumulation of gradients
  - Integrate p along x-direction (left to right)
  - Integrate q along y-direction (top to bottom)
  - Path-dependent: result depends on integration order
  """
  
  INPUT:
    - p: H×W gradient field (∂z/∂x)
    - q: H×W gradient field (∂z/∂y)
  
  OUTPUT:
    - z: H×W depth map
  
  INITIALIZATION:
    z = zeros(height, width)
    z[0, 0] = 0  /* Set first corner as reference */
  
  STEP 1: Integrate along x-direction (row-wise)
    FOR row FROM 0 TO height-1:
      FOR col FROM 1 TO width-1:
        z[row, col] = z[row, col-1] - p[row, col-1]
        
        /* Accumulate gradient:
           z[row, col] ≈ z[row, col-1] + Δz
           where Δz ≈ -p[row, col-1] × Δx
           (assuming Δx = 1 pixel)
        */
  
  STEP 2: Integrate along y-direction (column-wise)
    FOR col FROM 0 TO width-1:
      FOR row FROM 1 TO height-1:
        z[row, col] = z[row-1, col] - q[row-1, col]
        
        /* Similar accumulation in y-direction */
  
  RETURN z
```

### Characteristics

```
Advantages:
  ✓ Simple, easy to understand
  ✓ Fast computation O(HW)
  ✓ Direct numerical integration

Disadvantages:
  ✗ Path-dependent: different integration orders give different results
  ✗ Errors accumulate along integration path
  ✗ Very sensitive to noise
  ✗ Can produce "wavy" surfaces from noise accumulation
  
When noise added:
  - Error grows approximately as O(√(path_length))
  - Result is very noisy and unreliable
  - Only works well for clean gradient fields
```

---

## Method 2: Global Least-Squares (FFT-based)

### Background: FFT-based Poisson Solving

```
Problem: Solve Poisson equation ∇²z = div(p,q) globally

Solution in frequency domain:
  1. Compute divergence field: div = ∂p/∂x + ∂q/∂y
  2. Transform to frequency domain: div_FFT = FFT(div)
  3. Solve: z_FFT = div_FFT / (-(KX² + KY²))
     Where KX, KY = frequency grids
  4. Inverse transform: z = IFFT(z_FFT)

Advantage: Solves globally, minimizes total squared error
```

### Pseudocode

```
FUNCTION global_least_squares(p, q):
  """
  Reconstruct depth using FFT-based Poisson solver
  - Minimizes ||∇²z - div(p,q)||² globally
  - More robust to noise than simple integration
  """
  
  INPUT:
    - p, q: H×W gradient fields
  
  OUTPUT:
    - z: H×W depth map (globally optimal)
  
  STEP 1: Compute divergence field
    div = zeros(height, width)
    
    /* Central difference approximation:
       div[i,j] ≈ ∂p/∂x + ∂q/∂y
                ≈ (p[i,j+1] - p[i,j-1])/2 + (q[i+1,j] - q[i-1,j])/2
    */
    
    div[1:-1, 1:-1] = (
      (p[1:-1, 2:] - p[1:-1, :-2]) +  /* ∂p/∂x */
      (q[2:, 1:-1] - q[:-2, 1:-1])    /* ∂q/∂y */
    ) / 2
    
    /* Boundary: set to 0 (or use different boundary conditions) */
  
  STEP 2: Setup frequency domain
    kx = fft_frequency_grid(width)
    ky = fft_frequency_grid(height)
    
    [KX, KY] = create_meshgrid(kx, ky)
    /* KX[i,j] = frequency in x at position (i,j)
       KY[i,j] = frequency in y at position (i,j) */
  
  STEP 3: Create Poisson denominator
    denominator = -(KX² + KY²)
    /* Laplacian operator in frequency domain */
    
    denominator[0, 0] = 1
    /* Avoid division by zero at DC component (frequency 0,0)
       (This means we're setting the arbitrary constant) */
  
  STEP 4: FFT-based Poisson solving
    div_fft = fft_2d(div)
    z_fft = div_fft / denominator
    z = real(ifft_2d(z_fft))
    
    /* Solution to Poisson equation in spatial domain */
  
  RETURN z
```

### Characteristics

```
Advantages:
  ✓ Globally optimal (minimizes total squared error)
  ✓ Much more robust to noise than simple integration
  ✓ Produces smooth, consistent surfaces
  ✓ Fast O(HW log(HW)) using FFT

Disadvantages:
  ~ Requires FFT computation (slightly slower than simple integration)
  ~ Needs to handle DC component carefully
  
When noise added:
  - Error is "averaged out" globally
  - Result is smoothed but preserves overall shape
  - Much more stable than simple integration
```

---

## Method 3: Poisson Integration (Jacobi Iteration)

### Background: Jacobi Iteration

```
Solve ∇²z = div iteratively:

At each iteration k, update:
  z^(k+1)[i,j] = (z^(k)[i-1,j] + z^(k)[i+1,j] + 
                   z^(k)[i,j-1] + z^(k)[i,j+1] - div[i,j]) / 4

This is discrete Laplacian in spatial domain.
Iterate until convergence (residual < tolerance).
```

### Pseudocode

```
FUNCTION poisson_integration(p, q, max_iter=1000, tolerance=1e-6):
  """
  Reconstruct depth using iterative Poisson solver (Jacobi method)
  - Solves ∇²z = div(p,q) in spatial domain
  - Similar to FFT but iterative
  - Good for understanding and custom boundary conditions
  """
  
  INPUT:
    - p, q: H×W gradient fields
    - max_iter: Maximum iterations (default 1000)
    - tolerance: Convergence threshold (default 1e-6)
  
  OUTPUT:
    - z: H×W depth map
  
  STEP 1: Initialize depth
    z = zeros(height, width)
    z[0, 0] = 0  /* Set reference point */
  
  STEP 2: Compute divergence
    div = zeros(height, width)
    div[1:-1, 1:-1] = (
      (p[1:-1, 2:] - p[1:-1, :-2]) +
      (q[2:, 1:-1] - q[:-2, 1:-1])
    ) / 2
  
  STEP 3: Jacobi iteration
    FOR iteration FROM 0 TO max_iter:
      
      z_new = zeros_like(z)
      
      /* Update interior points using Laplacian stencil:
         [  0 -1  0]
         [-1  4 -1]  / 4
         [  0 -1  0]
      */
      
      z_new[1:-1, 1:-1] = (
        z[:-2, 1:-1] +      /* z[i-1, j] */
        z[2:, 1:-1] +       /* z[i+1, j] */
        z[1:-1, :-2] +      /* z[i, j-1] */
        z[1:-1, 2:] -       /* z[i, j+1] */
        div[1:-1, 1:-1]
      ) / 4
      
      /* Boundary conditions: usually Neumann (∂z/∂n = 0)
         Which means z_new[boundary] = z_new[boundary] */
      
      STEP 4: Check convergence
        max_change = maximum(abs(z_new - z))
        
        IF max_change < tolerance:
          PRINT f"Converged after {iteration} iterations"
          BREAK
      
      z = z_new
  
  RETURN z
```

### Characteristics

```
Advantages:
  ✓ Same global optimality as FFT method
  ✓ Flexible boundary conditions
  ✓ Easy to understand spatial domain approach
  ✓ Can stop early if good enough solution reached

Disadvantages:
  ~ Slower than FFT for large images
  ~ Requires tuning max_iter and tolerance
  ~ May not converge if tolerance too strict
  
Convergence:
  - Faster with smaller tolerance or higher max_iter
  - Typically converges in 100-500 iterations
  - Error decreases exponentially with iterations
  
When noise added:
  - Similar to FFT: globally optimal solution
  - Smoother than simple integration
  - Convergence may be slower with noise
```

---

## Comparison of Three Methods

```
                     Simple    Global LS  Jacobi Poisson
                   Integrat.  (FFT)      Iteration
                   ─────────────────────────────────────
Speed:             Fastest    Fast       Medium
Robustness:        Poor       Excellent  Excellent
Global optimality: No         Yes        Yes
Noise handling:    Bad        Good       Good
With noise:        Very noisy Smooth     Smooth
─────────────────────────────────────────────────────────

Recommendation for noisy data:
  Use FFT-based (global_least_squares) or Jacobi
  Avoid simple integration
```

---

# PART 5: NOISE AND ROBUSTNESS

**Objective**: Add noise and compare integration method robustness.

## Pseudocode - Add Gaussian Noise

```
FUNCTION add_gaussian_noise(data, noise_std=2.0):
  """
  Add zero-mean Gaussian noise to data
  """
  
  INPUT:
    - data: H×W array
    - noise_std: Standard deviation of noise
  
  OUTPUT:
    - noisy_data: H×W array with added noise
  
  STEP 1: Generate noise
    noise = random_normal(
      mean=0,
      std_dev=noise_std,
      shape=data.shape
    )
  
  STEP 2: Add to data
    noisy_data = data + noise
  
  RETURN noisy_data
```

## Pseudocode - Robustness Comparison

```
FUNCTION compare_robustness_to_noise(p, q, noise_levels=[1, 2, 5, 10]):
  """
  Reconstruct depth with different noise levels
  Compare stability of three methods
  """
  
  INPUT:
    - p, q: Clean gradient fields
    - noise_levels: List of noise standard deviations
  
  OUTPUT:
    - results: Dictionary with depth maps for each noise level
  
  INITIALIZATION:
    results = {}
  
  MAIN LOOP:
    FOR noise_level IN noise_levels:
      
      /* Add noise to gradients */
      p_noisy = add_gaussian_noise(p, noise_level)
      q_noisy = add_gaussian_noise(q, noise_level)
      
      /* Reconstruct with each method */
      z_simple = simple_integration(p_noisy, q_noisy)
      z_fft = global_least_squares(p_noisy, q_noisy)
      z_poisson = poisson_integration(p_noisy, q_noisy)
      
      results[noise_level] = {
        'simple': z_simple,
        'fft': z_fft,
        'poisson': z_poisson
      }
  
  RETURN results
```

---

# PART 6: ERROR ANALYSIS

**Objective**: Analyze how errors propagate through the pipeline.

## Error Sources and Propagation

```
ERROR PROPAGATION CHAIN:

1. Normal Map Errors
   ├─ Normalization errors: ||(nx, ny, nz)|| ≠ 1
   ├─ Data range errors: incorrect [0,1] → [-1,1] mapping
   ├─ Quantization noise: 8-bit representation
   └─ Sensor noise: measurement uncertainty

2. Gradient Extraction Errors
   ├─ Propagated from normal map errors
   ├─ Division by nz: amplifies when nz small
   └─ Become p, q errors: critical for integration

3. Integration Errors
   ├─ Simple integration: accumulates errors along path
   ├─ FFT/Poisson: averages errors globally (more stable)
   └─ Boundary effects: how edges are handled

4. Rendering Errors (Task 1)
   ├─ From normal errors: shading incorrect
   ├─ From albedo errors: brightness wrong
   └─ Combined: visible artifacts in rendered images
```

## Pseudocode - Error Analysis

```
FUNCTION analyze_error_propagation():
  """
  Investigate how normal and albedo errors affect results
  """
  
  STEP 1: Normalization errors
    
    ANALYSIS:
      What if normal vectors are not unit length?
      Example: ||(nx, ny, nz)|| = 0.9 instead of 1.0
      
    EFFECT ON RENDERING:
      dot_product = n · l (now scaled by 0.9)
      intensity becomes 10% dimmer everywhere
      All rendered images become systematically darker
    
    EFFECT ON GRADIENTS:
      p = -nx / nz (division by same scaled nz)
      Relative ratios preserved, but magnitudes scaled
      p_scaled = p_original × (||n_original|| / ||n_scaled||)
      This becomes systematic bias in gradients
    
    EFFECT ON DEPTH:
      Systematic bias accumulates throughout reconstruction
      Result: surface tilted or scaled incorrectly
  
  STEP 2: Data range errors
    
    ANALYSIS:
      What if normal map not mapped correctly?
      Example: Mapped to [-0.8, 0.8] instead of [-1, 1]
    
    EFFECT:
      nx, ny reduced by factor of 0.8
      nz reduced by factor of 0.8
      p = -nx / nz = -(0.8*nx_true) / (0.8*nz_true)
                   = -nx_true / nz_true (cancels out!)
      
      So relative gradients preserved
      But rendering affected: normals don't match light directions correctly
  
  STEP 3: Noise in gradients
    
    ANALYSIS:
      Random noise added to p, q
      What happens with different integration methods?
    
    EFFECT ON SIMPLE INTEGRATION:
      Errors accumulate along integration path
      Final error ~ O(√(path_length)) × noise_level
      Very noisy output
    
    EFFECT ON FFT/POISSON:
      Global optimization smooths noise
      Final error ~ O(noise_level)
      Much smoother output, preserves large-scale shape
  
  STEP 4: Mitigation strategies
    
    STRATEGY 1: Renormalize normals
      FOR each normal n:
        n_renormalized = n / ||n||
      Ensures unit length, fixes normalization errors
    
    STRATEGY 2: Verify data ranges
      Check that normals in [-1, 1]
      Check that albedo in [0, 1]
      Apply corrections if needed
    
    STRATEGY 3: Smooth noisy gradients
      Use Gaussian filtering on p, q before integration
      Reduces high-frequency noise
      Preserves low-frequency shape
    
    STRATEGY 4: Use robust integration method
      Prefer FFT or Poisson over simple integration
      Especially when gradients noisy
    
    STRATEGY 5: Post-process depth map
      Apply smoothing filter to final z
      Suppress noise-driven ripples
      Preserve large-scale features
```

---

# COMPLETE PIPELINE

## Pseudocode - Main Experiment

```
FUNCTION main_experiment():
  """
  Complete photometric stereo pipeline
  """
  
  ╔══════════════════════════════════════════════════════════════════╗
  ║ TASK 1: RENDER IMAGES UNDER DIFFERENT LIGHTING                   ║
  ╚══════════════════════════════════════════════════════════════════╝
  
  /* Load data */
  normal_map, albedo_map, lighting_matrix = load_data()
  
  /* Render 12 images */
  rendered_images = []
  FOR i IN 0..11:
    light_dir = lighting_matrix[i]
    rendered = render_image(normal_map, albedo_map, light_dir)
    rendered_images.append(rendered)
  
  /* Visualize */
  PLOT rendered_images in 3×4 grid
  SAVE 'rendered_images.png'
  
  ╔══════════════════════════════════════════════════════════════════╗
  ║ TASK 2: RECONSTRUCT DEPTH FROM NORMALS                           ║
  ╚══════════════════════════════════════════════════════════════════╝
  
  /* Extract gradients */
  p, q = extract_gradients(normal_map)
  
  /* Reconstruct with three methods (no noise) */
  z_simple = simple_integration(p, q)
  z_fft = global_least_squares(p, q)
  z_jacobi = poisson_integration(p, q)
  
  /* Add noise for robustness testing */
  p_noisy = add_gaussian_noise(p, noise_std=2.0)
  q_noisy = add_gaussian_noise(q, noise_std=2.0)
  
  /* Reconstruct with noise */
  z_simple_noisy = simple_integration(p_noisy, q_noisy)
  z_fft_noisy = global_least_squares(p_noisy, q_noisy)
  z_jacobi_noisy = poisson_integration(p_noisy, q_noisy)
  
  /* Visualize comparison */
  PLOT_FIGURE (2×3 subplots):
    Row 1 (no noise):
      - Simple Integration
      - FFT-based Poisson
      - Jacobi Iteration
    Row 2 (with noise):
      - Simple Integration (noisy)
      - FFT-based Poisson (noisy)
      - Jacobi Iteration (noisy)
  
  SAVE 'depth_reconstruction.png'
  
  ╔══════════════════════════════════════════════════════════════════╗
  ║ TASK 3: ERROR ANALYSIS (DISCUSSION)                              ║
  ╚══════════════════════════════════════════════════════════════════╝
  
  /* Qualitative observations */
  OBSERVE:
    - Simple integration with noise: very noisy output
    - FFT/Jacobi with noise: much smoother
    - FFT and Jacobi give similar results (both global optimization)
  
  /* Quantitative metrics (optional) */
  COMPUTE:
    - RMSE between clean and noisy reconstructions
    - Smoothness (TV norm or total variation)
    - Preservation of features (compare edges)
  
  ANALYZE error propagation:
    - How normal map errors affect rendering
    - How gradient extraction amplifies errors
    - How integration methods handle noise differently
  
  RECOMMEND mitigation:
    - Renormalize normals if needed
    - Use FFT/Jacobi for robustness
    - Consider post-processing smoothing
```

---

# VISUALIZATION GUIDE

## Pseudocode - Display Functions

```
FUNCTION plot_comparison_grid(results_dict, noise_levels):
  """
  Visualize depth maps side-by-side for comparison
  """
  
  CREATE figure with multiple subplots:
    Columns: 3 methods (Simple, FFT, Jacobi)
    Rows: Different noise levels
  
  FOR each noise level and method:
    subplot
    imshow(results_dict[noise_level][method], colormap='viridis')
    title(f'{method} - Noise σ={noise_level}')
    colorbar
    axis off
  
  tight_layout()
  save_figure('depth_comparison.png')
```

## Interpretation of Depth Maps

```
Colormap 'viridis':
  Purple (low values): Valleys, concave regions
  Blue: Mid-depth regions
  Green/Yellow: Higher regions
  Bright yellow (high values): Peaks, convex regions

Good reconstruction characteristics:
  ✓ Smooth transitions between colors
  ✓ No abrupt discontinuities
  ✓ Features correspond to visual structure
  ✓ Consistent with albedo map features

Poor reconstruction characteristics:
  ✗ Noisy, speckled appearance (noise accumulation)
  ✗ Artificial ripples or waves
  ✗ Disconnected regions
  ✗ Inverted features (peaks become valleys)
```

---

# KEY INSIGHTS AND COMPARISONS

## Method Robustness to Noise

```
Noise sensitivity ranking (worst to best):
  1. Simple Integration: VERY sensitive
     - Noise amplified along integration path
     - Final noise ~ √(path_length) × noise_std
     
  2. Jacobi Iteration: Robust
     - Global optimization averages noise
     - Final noise ~ noise_std
     - Smoother than simple integration
     
  3. FFT-based: Robust (similar to Jacobi)
     - Also global optimization
     - Equally smooth and stable
```

## Computational Complexity

```
Method         Time      Space    Best For
─────────────────────────────────────────────
Simple         O(HW)     O(HW)   Clean data only
FFT-based      O(HW log  O(HW)   Noisy data, speed
               HW)
Jacobi         O(kHW)    O(HW)   Noisy data, tuning
(k=iterations)

Where H=height, W=width
```

## When to Use Each Method

```
SIMPLE INTEGRATION:
  ✓ Educational purpose (understand gradients)
  ✓ Very clean, noise-free gradient data
  ✗ For any real data with noise

FFT-BASED:
  ✓ Production systems
  ✓ Real-time requirements (fast)
  ✓ Robust to moderate noise

JACOBI ITERATION:
  ✓ Custom boundary conditions needed
  ✓ Understanding iterative methods
  ✓ Adaptive stopping criteria useful
```

---

# ERROR MITIGATION STRATEGIES

## Strategy 1: Data Preprocessing

```
FUNCTION preprocess_normals(normal_map):
  """Renormalize and optionally smooth"""
  
  FOR each pixel:
    normal = [nx, ny, nz]
    length = sqrt(nx² + ny² + nz²)
    normal_normalized = normal / length
  
  /* Optional: apply Gaussian smoothing */
  normal_smoothed = gaussian_filter(normal_normalized, sigma=1.0)
  
  RETURN normal_smoothed
```

## Strategy 2: Robust Gradient Extraction

```
FUNCTION robust_gradient_extraction(normal_map, threshold=0.1):
  """Handle edge cases where nz is small"""
  
  nx, ny, nz = extract_components(normal_map)
  
  /* Where nz too small, gradient undefined */
  mask = abs(nz) > threshold
  
  p = zeros_like(nx)
  q = zeros_like(ny)
  
  p[mask] = -nx[mask] / nz[mask]
  q[mask] = -ny[mask] / nz[mask]
  
  RETURN p, q
```

## Strategy 3: Post-Processing Smoothing

```
FUNCTION smooth_depth_map(z, kernel_size=5, sigma=1.0):
  """Apply Gaussian smoothing to suppress noise"""
  
  z_smoothed = gaussian_filter(z, sigma=sigma)
  
  RETURN z_smoothed
```

---

# REFERENCES

- Photometric Stereo: https://en.wikipedia.org/wiki/Photometric_stereo
- Poisson Equation: https://en.wikipedia.org/wiki/Poisson%27s_equation
- FFT: https://en.wikipedia.org/wiki/Fast_Fourier_transform
- Jacobi Iteration: https://en.wikipedia.org/wiki/Jacobi_method
- Lambertian Reflectance: https://en.wikipedia.org/wiki/Lambertian_reflectance
