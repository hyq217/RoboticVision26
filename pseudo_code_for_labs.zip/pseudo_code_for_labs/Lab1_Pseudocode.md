# Lab 1: Image Processing & Edge Detection - Pseudocode

## Overview
This lab covers fundamental image processing concepts including convolution, edge detection (Sobel and Canny), and line detection using Hough Transform.

---

## Initialization & Setup

```
IMPORT required libraries:
  - skimage (image I/O and feature detection)
  - scipy (signal processing and convolution)
  - matplotlib.pyplot (visualization)
  - numpy (array operations)
  - cv2 (OpenCV, alternative implementation)

LOAD image:
  - READ 'shakey.jpg' using skimage.io.imread()
  - EXTRACT green channel (index [:,:,0])
  - STORE in variable 'shakey'

DISPLAY original image:
  - SHOW grayscale image using matplotlib
  - SET colormap to 'gray'
```

---

## Task 1: Reimplement Sobel Filter with OpenCV

**Objective**: Apply Sobel edge detection using OpenCV instead of SciPy

### Sobel Kernel Definition (Preprocessing)
```
sobel_x = [[1, 0, -1],
           [2, 0, -2],
           [1, 0, -1]]

sobel_y = [[1, 2, 1],
           [0, 0, 0],
           [-1, -2, -1]]
```

### Pseudocode - Method 1: Using cv2.filter2D
```
FUNCTION apply_sobel_opencv_filter2d(image, kernel):
  CONVERT image to float32 for precision
  FLIP kernel (because filter2D uses correlation, not convolution)
  APPLY filter using cv2.filter2D:
    - Input: image as float32
    - Kernel: flipped sobel_x kernel
    - Output depth: -1 (same as input)
  RESULT: filtered_image
  
THRESHOLD filtered image:
  COMPUTE absolute values of filtered_image
  COMPARE with threshold value (e.g., 50)
  RESULT: binary edge map
  
VISUALIZE:
  DISPLAY binary edge map with colormap 'gray'
```

### Pseudocode - Method 2: Using cv2.Sobel (Recommended)
```
FUNCTION apply_sobel_opencv_recommended(image):
  APPLY cv2.Sobel directly:
    - Input: image
    - Output data type: CV_64F (64-bit float)
    - x-derivative order: 1 (first derivative in x)
    - y-derivative order: 0 (no y derivative)
    - Kernel size: 3x3
  RESULT: sobel_x_gradient
  
  THRESHOLD:
    COMPUTE absolute values: abs(sobel_x_gradient)
    COMPARE with threshold (e.g., 50)
    RESULT: binary_edges
  
  VISUALIZE result
```

---

## Task 2: Apply Canny Edge Detection (OpenCV vs SciPy)

**Objective**: Compare two different implementations of the Canny edge detection algorithm

### Canny Algorithm Overview
```
1. Apply Gaussian smoothing to reduce noise
2. Compute image gradients (Sobel in x and y directions)
3. Suppress non-maximum gradients (keep only local maxima)
4. Apply double thresholding (strong, weak, non-edges)
5. Apply hysteresis to connect weak edges to strong edges
```

### Pseudocode - OpenCV Implementation
```
FUNCTION apply_canny_opencv(image, low_threshold, high_threshold):
  INPUT: 
    - image: grayscale image
    - low_threshold: lower edge threshold value
    - high_threshold: upper edge threshold value
  
  APPLY cv2.Canny:
    - Automatically applies Gaussian smoothing
    - Computes gradients
    - Performs non-maximum suppression
    - Applies double thresholding and hysteresis
  
  RESULT: edges (binary image)
  VISUALIZE with colormap 'gray'
```

### Pseudocode - SciPy (scikit-image) Implementation
```
FUNCTION apply_canny_scipy(image, sigma, low_threshold, high_threshold):
  INPUT:
    - image: grayscale image
    - sigma: Gaussian smoothing parameter (controls blur amount)
    - low_threshold: lower edge threshold
    - high_threshold: upper edge threshold
  
  APPLY feature.canny:
    - Applies Gaussian blur with parameter sigma
    - Computes gradients using Sobel
    - Performs non-maximum suppression
    - Applies double thresholding and hysteresis
  
  RESULT: edges (binary image)
  VISUALIZE result
```

### Parameter Notes
- **Threshold values**: 
  - Pixels with gradient < low_threshold: discarded (non-edges)
  - Pixels with gradient > high_threshold: kept (strong edges)
  - Pixels in between: kept if connected to strong edges
- **Sigma (SciPy only)**: Controls blur; higher values smooth more (less noise sensitivity, fewer details)

---

## Task 3: Straight Line Hough Transform

**Objective**: Detect straight lines in the image using Hough Transform

### Hough Transform Concept
```
Purpose: Find lines in image by voting in parameter space
- Image space: (x, y) pixel coordinates
- Hough space: (ρ, θ) - distance from origin and angle
- Each point in image space corresponds to a curve in Hough space
- Lines appear as intersections/peaks in Hough space
```

### Pseudocode - Method 1: Using scikit-image

```
FUNCTION hough_lines_skimage(edge_image):
  INPUT: edge_image (binary image from Canny)
  
  STEP 1: Define angle range
    tested_angles = linspace(-π/2, π/2, 360 angles)
  
  STEP 2: Compute Hough transform
    APPLY transform.hough_line():
      - Input: edge_image (binary edges)
      - Output: 
        * h: accumulator matrix (Hough space votes)
        * theta: angle values
        * d: distance values (ρ)
  
  STEP 3: Find peaks in Hough space
    APPLY transform.hough_line_peaks():
      - Input: h, theta, d from previous step
      - num_peaks: number of strongest lines to find (e.g., 10)
      - threshold: minimum vote count (e.g., 0.3 * max(h))
      - min_distance: minimum separation between peaks
      - Output: peaks containing strongest lines
  
  STEP 4: Visualize results
    CREATE 3 subplots:
      A. Original Canny edges
      B. Hough accumulator space (log scale, heat map)
      C. Original edges with detected lines overlaid
    
    FOR each detected line:
      EXTRACT angle and distance parameters
      COMPUTE line endpoints using image dimensions
      DRAW line on edge image
```

### Pseudocode - Method 2: Using OpenCV

```
FUNCTION hough_lines_opencv(edge_image):
  INPUT: edge_image (binary image from Canny)
  
  STEP 1: Apply Hough Line Transform
    APPLY cv2.HoughLines():
      - Input: edge_image (must be binary)
      - rho: distance resolution in pixels (e.g., 1)
      - theta: angle resolution in radians (e.g., π/180)
      - threshold: minimum vote count to detect a line (e.g., 250)
      - Output: lines array containing (ρ, θ) for each line
  
  STEP 2: Extract line parameters
    FOR each detected line in lines:
      EXTRACT rho and theta
  
  STEP 3: Convert to image coordinates
    FOR each line:
      COMPUTE a = cos(theta)
      COMPUTE b = sin(theta)
      COMPUTE x0 = a * rho, y0 = b * rho
      
      FOR visualization, extend line to image boundaries:
        COMPUTE (x1, y1) using extension length 1000
        COMPUTE (x2, y2) using extension length -1000
  
  STEP 4: Visualize
    CREATE 2 subplots:
      A. Original Canny edges
      B. Original grayscale image with detected lines
    
    FOR each line:
      DRAW line from (x1, y1) to (x2, y2) in red
```

### Parameter Tuning Guide
| Parameter | Effect | Task 1 | Task 2 | Task 3 |
|-----------|--------|--------|--------|--------|
| Low threshold | Lower = more edges detected | - | 50 | - |
| High threshold | Higher = fewer edges | - | 150 | - |
| Sigma | Blur amount (SciPy) | - | 1.0 | - |
| Hough threshold | Higher = only strong lines | - | - | 250 |
| Num peaks | Number of lines to find | - | - | 10 |

---

## Summary of Key Concepts

### Convolution vs Correlation
- **SciPy convolve2d**: True convolution (kernel is flipped)
- **OpenCV filter2D**: Correlation (kernel not flipped) - may need manual flip

### Edge Detection Algorithms
- **Sobel**: Simple, fast; detects edges using local gradients
- **Canny**: More sophisticated; multi-stage with hysteresis (better quality)

### Line Detection
- **Hough Transform**: Robust to broken lines, noise; finds dominant line directions
- **Parameter sensitivity**: Threshold significantly affects detection results

---

## References
- SciPy Convolution: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.convolve2d.html
- Scikit-image Canny: https://scikit-image.org/docs/stable/api/skimage.feature.html#canny
- OpenCV Edge Detection: https://docs.opencv.org/master/da/d22/tutorial_py_canny.html
- Hough Transform: https://en.wikipedia.org/wiki/Hough_transform
