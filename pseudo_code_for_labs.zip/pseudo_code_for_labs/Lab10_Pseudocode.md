# Lab 10: Monocular Depth Estimation with Depth Anything V2 - Pseudocode

## Overview
Lab 10 focuses on monocular depth estimation using a pretrained foundation model (**Depth Anything V2**).  
The workflow includes model loading, per-image depth inference, scale alignment to ground truth, quantitative error analysis, qualitative visualization, novel-view reprojection, and optional 3D point cloud exploration.

---

# MONODEPTH WORKFLOW

```
INPUT: RGB images (a, b, c), corresponding GT depth maps, intrinsic matrix K, pretrained Depth Anything V2 weights

STEP 1: Initialize environment and model
  ├─ Import libraries (OpenCV, NumPy, Torch, Matplotlib)
  ├─ Build Depth Anything V2 model
  ├─ Load pretrained checkpoint
  └─ Set model to evaluation mode (GPU if available)

STEP 2: Process each image
  ├─ Read RGB image and GT depth
  ├─ Infer raw monocular depth with model
  ├─ Align predicted depth scale to GT range
  ├─ Compute quantitative metrics (MAE, RMSE)
  └─ Save results in a dictionary

STEP 3: Qualitative evaluation
  ├─ Visualize predicted depth maps
  ├─ Visualize L1 error maps (|pred - GT|)
  └─ Compare failures on boundaries / textureless regions

STEP 4: View synthesis
  ├─ Reproject pixels using predicted depth + K
  ├─ Transform 3D points to a new camera pose
  └─ Render warped image for novel-view inspection

STEP 5: 3D point cloud reconstruction (optional)
  ├─ Unproject pixels into 3D with depth
  ├─ Attach RGB colors
  └─ Display / save sparse or dense point cloud

OUTPUT: Predicted depth maps, MAE/RMSE statistics, L1 maps, reprojected views, optional point clouds
```

---

# PART 1: MODEL SETUP

**Objective**: Initialize Depth Anything V2 and load pretrained weights.

## Pseudocode - Build and Load Model

```
FUNCTION setup_depth_anything_v2(ckpt_path, encoder='vitl', max_depth=20.0):
  """
  Build Depth Anything V2 model and load checkpoint
  """

  INPUT:
    - ckpt_path: file path to pretrained model weights
    - encoder: backbone type ('vits', 'vitb', 'vitl')
    - max_depth: max depth range expected by model

  OUTPUT:
    - model: initialized model in eval mode
    - device: 'cuda' or 'cpu'

  STEP 1: Select device
    IF cuda_available():
      device = 'cuda'
    ELSE:
      device = 'cpu'

  STEP 2: Create model
    model = DepthAnythingV2(
      encoder=encoder,
      features=...,            /* depends on selected encoder config */
      out_channels=...,
      max_depth=max_depth
    )

  STEP 3: Load checkpoint
    state_dict = torch_load(ckpt_path, map_location=device)
    model.load_state_dict(state_dict)

  STEP 4: Move and finalize
    model.to(device)
    model.eval()

  RETURN model, device
```

---

# PART 2: DATA LOADING

**Objective**: Load RGB images and metric ground-truth depth maps.

## Pseudocode - Read Inputs

```
FUNCTION load_rgb_and_gt(base_dir, image_name):
  """
  Read one RGB image and its GT depth map
  """

  INPUT:
    - base_dir: directory containing imgs
    - image_name: 'a' or 'b' or 'c'

  OUTPUT:
    - rgb: HxWx3 uint8 image (BGR from OpenCV)
    - gt_depth: HxW float32 depth map in meters

  rgb_path = f"{base_dir}/{image_name}.png"
  gt_path  = f"{base_dir}/{image_name}_gt_depth.png"

  rgb = cv2_imread(rgb_path, mode=COLOR)
  gt_raw = cv2_imread(gt_path, mode=UNCHANGED)

  IF rgb is None OR gt_raw is None:
    RAISE FileNotFoundError

  /* GT stored as millimeters in png channel */
  gt_depth = convert_to_float32(gt_raw[..., 0]) / 1000.0

  RETURN rgb, gt_depth
```

---

# PART 3: MONOCULAR DEPTH INFERENCE

**Objective**: Run Depth Anything V2 to predict raw depth.

## Pseudocode - Inference

```
FUNCTION infer_depth_map(model, rgb):
  """
  Infer monocular depth from one RGB image
  """

  INPUT:
    - model: loaded Depth Anything V2
    - rgb: HxWx3 image

  OUTPUT:
    - pred_depth_raw: HxW float32 depth prediction

  STEP 1: Call model inference helper
    pred_depth_raw = model.infer_image(rgb)

  STEP 2: Ensure numerical validity
    pred_depth_raw = convert_to_float32(pred_depth_raw)
    pred_depth_raw = replace_nan_or_inf(pred_depth_raw, value=0)

  RETURN pred_depth_raw
```

---

# PART 4: SCALE ALIGNMENT FOR MONODEPTH

**Objective**: Align model output scale with GT depth for fair evaluation.

## Background

```
Monocular depth is typically scale-ambiguous:
  - Relative structure is often good
  - Absolute metric scale may be shifted/scaled

So we align prediction to GT using valid pixels before MAE/RMSE.
```

## Pseudocode - Linear Scale Alignment

```
FUNCTION align_depth_to_gt(pred_raw, gt_depth, eps=1e-8):
  """
  Align predicted depth to GT with robust linear scaling
  pred_aligned = s * pred_raw + t
  """

  INPUT:
    - pred_raw: HxW predicted raw depth
    - gt_depth: HxW ground truth depth (meters)

  OUTPUT:
    - pred_aligned: HxW scale-corrected depth
    - scale_s, shift_t: alignment parameters

  STEP 1: Create valid mask
    mask = (gt_depth > 0) AND finite(gt_depth) AND finite(pred_raw)

  STEP 2: Flatten valid values
    p = pred_raw[mask]
    g = gt_depth[mask]

  STEP 3: Solve least-squares linear fit
    /* minimize ||s*p + t - g||^2 */
    A = [p, ones_like(p)]      /* shape N x 2 */
    [s, t] = least_squares(A, g)

  STEP 4: Apply transform
    pred_aligned = s * pred_raw + t
    pred_aligned = maximum(pred_aligned, eps)  /* avoid non-positive depths */

  RETURN pred_aligned, s, t
```

---

# PART 5: QUANTITATIVE EVALUATION

**Objective**: Compute MAE/RMSE between aligned prediction and GT.

## Pseudocode - Metrics

```
FUNCTION compute_depth_metrics(gt_depth, pred_depth):
  """
  Compute MAE and RMSE on valid GT pixels
  """

  INPUT:
    - gt_depth: HxW ground truth
    - pred_depth: HxW predicted (aligned)

  OUTPUT:
    - metrics: {mae, rmse, num_valid}

  mask = (gt_depth > 0) AND finite(gt_depth) AND finite(pred_depth)

  gt_v = gt_depth[mask]
  pr_v = pred_depth[mask]

  abs_err = abs(pr_v - gt_v)
  sq_err  = (pr_v - gt_v)^2

  mae  = mean(abs_err)
  rmse = sqrt(mean(sq_err))

  RETURN {
    'mae': mae,
    'rmse': rmse,
    'num_valid': length(gt_v)
  }
```

---

# PART 6: QUALITATIVE VISUALIZATION

**Objective**: Inspect depth quality via depth rendering and L1 error map.

## Pseudocode - Visualization

```
FUNCTION visualize_depth_and_l1(rgb, gt_depth, pred_depth_aligned, title_prefix):
  """
  Show RGB, predicted depth, GT depth, and L1 error map
  """

  l1_map = abs(pred_depth_aligned - gt_depth)

  CREATE figure with 1x4 subplots

  SUBPLOT 1: RGB image
    show(convert_BGR_to_RGB(rgb))
    title(f"{title_prefix} RGB")

  SUBPLOT 2: Predicted depth
    show(pred_depth_aligned, cmap='magma')
    title("Predicted Depth (aligned)")
    add_colorbar()

  SUBPLOT 3: Ground truth depth
    show(gt_depth, cmap='magma')
    title("GT Depth")
    add_colorbar()

  SUBPLOT 4: L1 difference
    show(l1_map, cmap='jet')
    title("L1 Error |Pred - GT|")
    add_colorbar()

  tight_layout()
  display_figure()
```

---

# PART 7: REPROJECTION TO NOVEL VIEW

**Objective**: Reproject image using predicted depth to evaluate geometric consistency.

## Pseudocode - View Synthesis

```
FUNCTION reproject_with_depth(rgb, depth, K, T_new_from_old):
  """
  Warp source image into a new camera viewpoint
  """

  INPUT:
    - rgb: source image HxWx3
    - depth: source depth HxW
    - K: 3x3 intrinsic matrix
    - T_new_from_old: 4x4 rigid transform

  OUTPUT:
    - warped: HxWx3 reprojected image

  STEP 1: Create pixel grid
    (u, v) = meshgrid over image coordinates

  STEP 2: Unproject to 3D (old camera frame)
    X = (u - cx) * depth / fx
    Y = (v - cy) * depth / fy
    Z = depth

  STEP 3: Transform points to new camera frame
    P_old = [X, Y, Z, 1]
    P_new = T_new_from_old @ P_old

  STEP 4: Project to image plane
    p = K @ P_new[:3]
    u_new = p_x / p_z
    v_new = p_y / p_z

  STEP 5: Remap colors
    warped = remap(rgb, map_x=u_new, map_y=v_new, interpolation=linear)

  RETURN warped
```

---

# PART 8: 3D POINT CLOUD FROM MONODEPTH

**Objective**: Convert per-pixel depth to colored 3D points.

## Pseudocode - Point Cloud Generation

```
FUNCTION depth_to_point_cloud(rgb, depth, K, stride=2):
  """
  Convert depth map to colored point cloud
  """

  INPUT:
    - rgb: HxWx3 image
    - depth: HxW depth map
    - K: 3x3 intrinsics
    - stride: subsampling factor for faster plotting

  OUTPUT:
    - points_xyz: Nx3 3D coordinates
    - colors_rgb: Nx3 colors in [0, 1]

  INITIALIZE empty lists points, colors

  FOR v from 0 to H-1 step stride:
    FOR u from 0 to W-1 step stride:
      z = depth[v, u]
      IF z <= 0 OR not finite(z):
        CONTINUE

      x = (u - cx) * z / fx
      y = (v - cy) * z / fy

      points.append([x, y, z])
      colors.append(rgb[v, u] converted BGR->RGB and normalized)

  RETURN as arrays(points), arrays(colors)
```

---

# PART 9: COMPLETE PIPELINE

## Pseudocode - Main Function

```
FUNCTION main_lab10_pipeline():
  """
  Complete Lab10 experiment pipeline
  """

  # Setup
  model, device = setup_depth_anything_v2(ckpt_path=".../depth_anything_v2.pth")
  K = [[600, 0, 600],
       [0, 600, 300],
       [0,   0,   1]]
  image_names = ['a', 'b', 'c']

  results = {}

  FOR name IN image_names:
    rgb, gt = load_rgb_and_gt(base_dir="Lab10/imgs", image_name=name)

    pred_raw = infer_depth_map(model, rgb)
    pred_aligned, s, t = align_depth_to_gt(pred_raw, gt)

    metrics = compute_depth_metrics(gt, pred_aligned)
    l1_map = abs(pred_aligned - gt)

    visualize_depth_and_l1(rgb, gt, pred_aligned, title_prefix=f"Image {name}")

    results[name] = {
      'scale': s,
      'shift': t,
      'mae': metrics['mae'],
      'rmse': metrics['rmse'],
      'l1_mean': mean(l1_map)
    }

    # Optional reprojection
    T = build_small_y_rotation(angle_deg=15)
    warped = reproject_with_depth(rgb, pred_aligned, K, T)
    display(warped)

    # Optional point cloud
    pts, cols = depth_to_point_cloud(rgb, pred_aligned, K, stride=3)
    plot_3d_scatter(pts, cols)

  PRINT "=== Final quantitative report ==="
  FOR each name in ['a', 'b', 'c']:
    PRINT name, results[name]['mae'], results[name]['rmse'], results[name]['l1_mean']
```

---

# NOTES FOR IMPLEMENTATION

```
1) Keep model inference in eval mode and no_grad() for speed/memory.
2) Always evaluate metrics on valid GT pixels only (gt > 0).
3) Monocular predictions need scale alignment before MAE/RMSE comparison.
4) Reprojection artifacts near occlusion boundaries are expected.
5) If point cloud is too dense, increase stride for faster visualization.
```
