# Lab 3: 3D Geometry and Camera Projections - Pseudocode

## Overview
Lab 3 focuses on implementing 3D-to-2D projection and point cloud rasterization using camera matrices. Students learn to construct extrinsic and intrinsic matrices, form projection matrices, and render 3D point clouds to 2D images.

---

# STEP 1: DEFINING THE EXTRINSIC MATRIX

**Objective**: Convert camera pose (camera center and rotation) to extrinsic matrix for transforming world coordinates to camera frame.

## Background: Camera Pose vs Extrinsic Matrix

```
Camera Pose [R_c | C]:
  - Describes camera position and orientation in world coordinates
  - R_c: 3×3 rotation matrix (camera orientation in world frame)
  - C: 3×1 translation vector (camera center in world coordinates)

Extrinsic Matrix [R | t]:
  - Transforms 3D world points to camera frame coordinates
  - Relationship: [R | t] = inverse([R_c | C])
  - Formula: R = R_c^T (transpose), t = -R_c^T @ C
```

## Pseudocode - Extrinsic Matrix Calculation

```
FUNCTION calculate_extrinsic_matrix(camera_rotation_R_c, camera_center_C):
  """
  Convert camera pose to extrinsic matrix using matrix inversion formula
  """
  
  INPUT:
    - camera_rotation_R_c: 3×3 rotation matrix describing camera orientation
    - camera_center_C: 3×1 vector of camera position in world coordinates
  
  STEP 1: Extract rotation component
    R = transpose(R_c)
    /* R = R_c^T */
  
  STEP 2: Compute translation component
    t = -1 * R @ C
    /* t = -R_c^T @ C */
  
  STEP 3: Build 4×4 homogeneous matrix
    extrinsic_matrix = identity(4)
    extrinsic_matrix[0:3, 0:3] = R       (upper-left 3×3 block)
    extrinsic_matrix[0:3, 3] = t        (upper-right 3×1 block)
    extrinsic_matrix[3, :] = [0, 0, 0, 1] (bottom row for homogeneous coordinates)
  
  PRINT extrinsic_matrix
  
  RETURN extrinsic_matrix (4×4 matrix)
```

## Mathematical Verification

```
Verification formula (for understanding):
  [R | t]     [R_c | C ]^-1
  [0 | 1]  =  [0   | 1 ]
  
           = [R_c^T | -R_c^T C]
             [0     | 1      ]
  
This ensures that when applied to world points, they are correctly 
transformed to the camera coordinate system.
```

---

# STEP 2: DEFINING THE INTRINSIC MATRIX

**Objective**: Construct the camera intrinsic matrix containing calibration parameters.

## Background: Camera Intrinsics

```
The intrinsic matrix K encodes:
- fx, fy: Focal lengths in x and y directions (in pixels)
- ppx, ppy: Principal point (optical center) offsets
- s: Skew coefficient (usually 0 for most modern cameras)

Matrix form:
K = [fx   s  ppx]
    [0   fy  ppy]
    [0    0    1 ]
```

## Pseudocode - Intrinsic Matrix Construction

```
FUNCTION construct_intrinsic_matrix(focal_length_x, focal_length_y, 
                                   principal_point_x, principal_point_y, 
                                   skew):
  """
  Build the 3×3 intrinsic camera matrix
  """
  
  INPUT:
    - focal_length_x (fx): Focal length in x direction (pixels)
    - focal_length_y (fy): Focal length in y direction (pixels)
    - principal_point_x (ppx): Principal point x offset (pixels)
    - principal_point_y (ppy): Principal point y offset (pixels)
    - skew (s): Skew coefficient (typically 0)
  
  STEP 1: Create 3×3 matrix with zeros
    K = zeros(3, 3)
  
  STEP 2: Fill diagonal focal length terms
    K[0, 0] = focal_length_x    (fx)
    K[1, 1] = focal_length_y    (fy)
    K[2, 2] = 1
  
  STEP 3: Fill skew term
    K[0, 1] = skew              (s)
  
  STEP 4: Fill principal point terms
    K[0, 2] = principal_point_x (ppx)
    K[1, 2] = principal_point_y (ppy)
  
  RESULT:
    K = [[fx,  s, ppx],
         [0,  fy, ppy],
         [0,   0,   1 ]]
  
  PRINT K
  
  RETURN K (3×3 matrix)
```

## Common Parameters

```
Typical camera calibration values:
- fx, fy: 400-2000 pixels (depends on sensor size and focal length)
- ppx, ppy: Usually near image center (width/2, height/2)
- s (skew): 0 for nearly all modern cameras
- Image size: 640×480, 800×600, 1920×1080, etc.
```

---

# STEP 3: FORMING THE PROJECTION MATRIX

**Objective**: Combine intrinsic and extrinsic matrices to create the complete projection matrix.

## Background: Projection Matrix

```
The projection matrix P combines camera calibration and pose:

P = K @ [R | t]

Where:
- K: 3×3 intrinsic matrix
- [R | t]: 3×4 extrinsic matrix (first 3 rows)
- P: 3×4 projection matrix
- Result: 3D homogeneous point → 2D image coordinate
```

## Pseudocode - Projection Matrix Construction

```
FUNCTION construct_projection_matrix(intrinsic_matrix_K, 
                                     extrinsic_matrix_4x4):
  """
  Combine intrinsic and extrinsic matrices
  """
  
  INPUT:
    - intrinsic_matrix_K: 3×3 camera intrinsic matrix
    - extrinsic_matrix_4x4: 4×4 extrinsic matrix (from Step 1)
  
  STEP 1: Extract 3×4 portion of extrinsic matrix
    extrinsic_3x4 = extrinsic_matrix_4x4[0:3, :]
    /* Extract first 3 rows, all 4 columns */
  
  STEP 2: Perform matrix multiplication
    P = K @ extrinsic_3x4
    /* Matrix multiplication: 3×3 @ 3×4 = 3×4 */
  
  STEP 3: Verify result shape
    IF shape(P) != (3, 4):
      ERROR: "Projection matrix has wrong dimensions"
  
  PRINT P
  
  RETURN P (3×4 matrix)
```

## Projection Matrix Usage

```
Once P is constructed, any 3D point can be projected:

Given world point P_world = [X, Y, Z, 1]^T (homogeneous)

1. Project: p_homogeneous = P @ P_world  (3×1 vector [u', v', w'])
2. Normalize: u = u' / w', v = v' / w'
3. Result: (u, v) = 2D image coordinates
```

---

# STEP 4: LOADING POINT CLOUD DATA

**Objective**: Load 3D point cloud using Open3D library.

## Background: Open3D PointCloud Structure

```
Open3D PointCloud contains:
- points: N×3 array of 3D coordinates [X, Y, Z]
- colors: N×3 array of RGB values [0, 1] (float) or [0, 255] (uint8)
- normals: N×3 array of surface normal vectors (optional)
```

## Pseudocode - Load Point Cloud

```
FUNCTION load_point_cloud(file_path):
  """
  Load point cloud from file using Open3D
  """
  
  INPUT:
    - file_path: Path to point cloud file (.ply, .pcd, etc.)
  
  STEP 1: Load point cloud
    point_cloud = open3d.io.read_point_cloud(file_path)
  
  STEP 2: Extract points and colors
    points = numpy_array(point_cloud.points)     /* N×3 array */
    colors = numpy_array(point_cloud.colors)     /* N×3 array, [0,1] */
  
  STEP 3: Print statistics
    num_points = shape(points)[0]
    PRINT "Number of points:", num_points
    PRINT "First 10 points:"
    PRINT points[0:10, :]
    PRINT "First 10 colors:"
    PRINT colors[0:10, :]
  
  RETURN points, colors
```

## File Formats Supported

```
- .ply (Polygon): ASCII or binary format
- .pcd (Point Cloud Data): ASCII or binary format
- .xyz: ASCII XYZ coordinates
- .xyzrgb: ASCII XYZ with RGB colors
```

---

# STEP 5: PROJECT THE POINT CLOUD

**Objective**: Transform 3D points to 2D image coordinates using the projection matrix.

## Background: Homogeneous Coordinate Projection

```
Process:
1. Convert 3D points to homogeneous: [X, Y, Z] → [X, Y, Z, 1]
2. Apply projection matrix: p' = P @ p_homo
3. Normalize by third coordinate (perspective division): divide (u, v) by w
4. Result: 2D image coordinates (u, v)
```

## Pseudocode - Point Cloud Projection

```
FUNCTION project_point_cloud(points_3D, projection_matrix_P):
  """
  Apply projection matrix to transform 3D points to 2D image coordinates
  """
  
  INPUT:
    - points_3D: N×3 array of 3D world points
    - projection_matrix_P: 3×4 projection matrix
  
  STEP 1: Extract number of points
    N = shape(points_3D)[0]
  
  STEP 2: Convert to homogeneous coordinates
    ones_column = ones(N, 1)
    points_homogeneous = concatenate([points_3D, ones_column], axis=1)
    /* Result: N×4 array */
  
  STEP 3: Apply projection matrix
    projected_points = (P @ points_homogeneous^T)^T
    /* Matrix multiply: (3×4) @ (4×N) = (3×N), then transpose to (N×3) */
  
  STEP 4: Extract coordinates
    u_projected = projected_points[:, 0]    (x-coordinates)
    v_projected = projected_points[:, 1]    (y-coordinates)
    w = projected_points[:, 2]              (homogeneous depth)
  
  STEP 5: Normalize by depth (perspective division)
    FOR each point i:
      IF w[i] > 0:
        u_projected[i] = u_projected[i] / w[i]
        v_projected[i] = v_projected[i] / w[i]
      ELSE:
        MARK point as invalid (behind camera)
  
  STEP 6: Extract 2D coordinates
    uv_coordinates = concatenate([u_projected, v_projected], axis=1)
    /* Result: N×2 array of 2D image coordinates */
  
  STEP 7: Print first 10 projected points
    PRINT "First 10 projected (u, v) points:"
    PRINT uv_coordinates[0:10, :]
  
  RETURN uv_coordinates (N×2 array)
```

## Important Considerations

```
- Points with w ≤ 0 are behind the camera (invalid projections)
- Points with w near zero cause numerical instability (infinity in normalization)
- Projected coordinates can be negative or outside image bounds
- Next step (rasterization) will filter out-of-bounds points
```

---

# STEP 6: RASTERIZE POINTS ONTO IMAGE ARRAY

**Objective**: Draw the 2D projected point cloud onto a 2D image buffer.

## Background: Rasterization Process

```
Rasterization converts vector data (point coordinates) to raster data (pixel grid)

Process:
1. Create empty image buffer (H × W × 3)
2. For each projected point:
   - Round to nearest pixel coordinates
   - Check if within image bounds
   - Set image pixel to point's color
```

## Pseudocode - Rasterization

```
FUNCTION rasterize_point_cloud(uv_coordinates, colors, image_width, image_height):
  """
  Draw projected points onto image array
  """
  
  INPUT:
    - uv_coordinates: N×2 array of 2D image coordinates (from Step 5)
    - colors: N×3 array of RGB colors [0, 1]
    - image_width: Width of output image (pixels)
    - image_height: Height of output image (pixels)
  
  STEP 1: Initialize image buffer
    image = zeros(image_height, image_width, 3)
    /* Initialized to black */
  
  STEP 2: Extract u and v coordinates
    u = uv_coordinates[:, 0]
    v = uv_coordinates[:, 1]
  
  STEP 3: Round to pixel coordinates
    x_pixel = round_to_integer(u)
    y_pixel = round_to_integer(v)
  
  STEP 4: Create validity mask
    valid_mask = (x_pixel >= 0) AND (x_pixel < image_width) AND
                 (y_pixel >= 0) AND (y_pixel < image_height)
    /* Boolean array indicating which points are in bounds */
  
  STEP 5: Filter valid points
    x_valid = x_pixel[valid_mask]
    y_valid = y_pixel[valid_mask]
    colors_valid = colors[valid_mask]
  
  STEP 6: Rasterize onto image
    FOR i = 0 to length(x_valid):
      x = x_valid[i]
      y = y_valid[i]
      image[y, x] = colors_valid[i]
      /* Note: In image coordinates, y is row, x is column */
  
  STEP 7: Display image
    CREATE figure
    IMSHOW image
    REMOVE axis labels
    DISPLAY
  
  RETURN image
```

## Important Notes

```
- Image indexing: image[row, column] = image[y, x]
- Pixel coordinates are integers (0 to width-1, 0 to height-1)
- Out-of-bounds points are silently discarded
- If multiple points map to same pixel, later points overwrite earlier ones
  (see Question 1 for depth buffering solution)
```

---

# STEP 7: ALTERNATIVE CAMERA VIEWPOINT (TOP-DOWN VIEW)

**Objective**: Create rendering from a different camera viewpoint to demonstrate multi-view rendering.

## Background: Top-Down View Camera Configuration

```
Top-down view characteristics:
- Camera positioned above the scene looking downward
- Useful for bird's-eye view perspective
- Can help verify 3D scene structure
```

## Pseudocode - Top-Down View Generation

```
FUNCTION generate_top_down_view(point_cloud):
  """
  Create a top-down (bird's-eye) view of the scene
  """
  
  INPUT:
    - point_cloud: Open3D point cloud object
  
  STEP 1: Extract points and compute scene center
    points = numpy_array(point_cloud.points)
    center = mean(points, axis=0)
    /* Center of bounding box */
  
  STEP 2: Define new camera position (above scene)
    C_top = center + [0.0, offset_height, 0.0]
    /* offset_height: distance above scene center */
    /* Typically 2-5 times the scene's vertical extent */
  
  STEP 3: Define up vector in world coordinates
    up_world = [0.0, 0.0, 1.0]  (Z-axis points up)
  
  STEP 4: Calculate forward vector
    forward = (center - C_top)
    forward = normalize(forward)
    /* Direction from camera to scene center */
  
  STEP 5: Calculate right vector (camera X-axis)
    right = cross_product(up_world, forward)
    right = normalize(right)
    /* Perpendicular to both up and forward */
  
  STEP 6: Recalculate up vector for orthogonal frame
    up = cross_product(forward, right)
    /* Ensures orthogonal camera coordinate frame */
  
  STEP 7: Build rotation matrix (camera orientation in world frame)
    R_c_top = stack_as_rows([right, up, forward])
    /* 3×3 matrix with normalized basis vectors */
  
  STEP 8: Print new camera configuration
    PRINT "Top-down camera center C_top:", C_top
    PRINT "Top-down rotation matrix R_c_top:"
    PRINT R_c_top
  
  STEP 9: Render from new viewpoint (optional)
    extrinsic_top = calculate_extrinsic_matrix(R_c_top, C_top)
    P_top = K @ extrinsic_top[:3, :]
    
    uv_top = project_point_cloud(points, P_top)
    image_top = rasterize_point_cloud(uv_top, colors, width, height)
    
    DISPLAY image_top
  
  RETURN C_top, R_c_top
```

## Alternative Viewpoints

```
Different camera positions for visualization:

TOP-DOWN:
  C = scene_center + [0, height, 0]
  
SIDE VIEW (from right):
  C = scene_center + [distance, 0, 0]
  
FRONT VIEW:
  C = scene_center + [0, 0, -distance]
  
ISOMETRIC VIEW (45° angle):
  C = scene_center + [distance, height, distance]
```

---

# QUESTIONS: CRITICAL THINKING

---

## Q1: Occlusion Problem - Stacked Points

**Question**: What happens when two 3D points project onto the same 2D pixel?

### Problem Analysis

```
Current algorithm behavior:
  When multiple 3D points project to same (x, y):
    - First point writes color to image[y, x]
    - Second point OVERWRITES with its color
    - Later points erase earlier ones
    
  Result:
    - Loss of depth information
    - No way to determine which point is in front
    - Incorrect rendering of overlapping geometry
```

### Solution 1: Depth Buffering (Z-Buffer Algorithm)

```
FUNCTION rasterize_with_depth_buffer(uv_coordinates, colors, depths, 
                                     image_width, image_height):
  """
  Use depth buffer to resolve occlusion
  """
  
  INPUT:
    - uv_coordinates: N×2 2D projection coordinates
    - colors: N×3 RGB colors
    - depths: N×1 depth/Z-values from projection
    - image dimensions
  
  INITIALIZATION:
    image = zeros(image_height, image_width, 3)
    depth_buffer = +infinity array (same size as image)
    
  MAIN LOOP:
    FOR each point i:
      x, y = round(uv_coordinates[i])
      z = depths[i]
      
      IF (0 <= x < width) AND (0 <= y < height):
        IF z < depth_buffer[y, x]:  /* Point is closer */
          image[y, x] = colors[i]
          depth_buffer[y, x] = z
        ELSE:  /* Point is occluded, skip */
          CONTINUE
  
  RETURN image
  
  Effect: Only the closest point at each pixel is rendered
```

### Solution 2: Average/Blending

```
Instead of overwriting, accumulate color values:

FUNCTION rasterize_with_blending(...):
  
  FOR each point i:
    x, y = round(uv_coordinates[i])
    
    IF in_bounds(x, y):
      /* Blend colors (e.g., average or weighted sum) */
      alpha = 0.5  (blend factor)
      image[y, x] = alpha * image[y, x] + (1-alpha) * colors[i]
```

---

## Q2: Scaling the Point Cloud

**Question**: How would you modify the algorithm to scale the points?

### Scaling Methods

#### Method 1: Scale Before Projection

```
FUNCTION scale_and_render(points_3D, scale_factor, P, colors):
  """
  Scale 3D points before projection
  """
  
  INPUT:
    - points_3D: Original N×3 point coordinates
    - scale_factor: Scalar value (e.g., 2.0 for 2x enlargement)
    - P: Projection matrix
    - colors: RGB colors
  
  STEP 1: Apply scaling
    points_scaled = scale_factor * points_3D
    /* Isotropic scaling (uniform in all directions) */
  
  STEP 2: Project and rasterize
    uv = project_point_cloud(points_scaled, P)
    image = rasterize_point_cloud(uv, colors, width, height)
  
  RETURN image
  
  Effect:
    - scale_factor > 1: Scene appears larger in image
    - scale_factor < 1: Scene appears smaller in image
    - All objects scale uniformly
```

#### Method 2: Anisotropic Scaling (Different per axis)

```
FUNCTION scale_anisotropic(points_3D, scale_x, scale_y, scale_z):
  """
  Scale differently in each direction
  """
  
  CREATE scaling matrix:
    S = [[scale_x,  0,        0      ],
         [0,        scale_y,  0      ],
         [0,        0,        scale_z]]
  
  APPLY to points:
    points_scaled = points_3D @ S^T  (or S @ points_3D^T then transpose)
  
  Effect:
    - Non-uniform scaling
    - Can stretch/compress in specific dimensions
    - Useful for aspect ratio correction
```

#### Method 3: Scale in Image Space

```
FUNCTION scale_image(image, scale_factor):
  """
  Scale the rendered image after rasterization
  """
  
  new_height = int(height * scale_factor)
  new_width = int(width * scale_factor)
  
  scaled_image = interpolate_image(image, new_height, new_width)
  
  RETURN scaled_image
  
  Effect:
    - Scales entire rendered image
    - May lose detail (downscaling) or blur (upscaling)
    - Different from 3D scaling (interpolation artifacts)
```

#### Method 4: Point Size Splat

```
FUNCTION render_with_point_size(uv_coordinates, colors, radius):
  """
  Render each point as a circle of given radius
  """
  
  FOR each projected point (u, v) with color c:
    FOR all pixels (px, py) where:
      distance((px, py), (u, v)) <= radius:
        image[py, px] = c
  
  Effect:
    - Creates point splats instead of single pixels
    - Effective "scaling" of point representation
    - Smoother appearance
```

### Pseudocode Comparison

| Method | When to Use | Effect |
|--------|------------|--------|
| Before projection | When working with 3D data | Accurate geometric scaling |
| Anisotropic | For correcting aspect ratios | Non-uniform transformation |
| Image space | Post-processing | Quick magnification/reduction |
| Point splat | For visualization | Smoother rendering |

---

## Q3: Effects of Focal Length (fx, fy)

**Question**: What is the effect of increasing/decreasing fx and fy values?

### Mathematical Relationship

```
In the projection equation:
  u = fx * (X_camera / Z_camera) + ppx
  v = fy * (Y_camera / Z_camera) + ppy

Where:
  - u, v: 2D image coordinates
  - X_camera, Y_camera, Z_camera: 3D camera frame coordinates
  - fx, fy: Focal lengths (pixels)
  - ppx, ppy: Principal point offsets
```

### Effects Analysis

#### Case 1: Increase fx and fy (Larger Focal Length)

```
Example: fx = 400 → fx = 800

Effect on projection:
  u_new = 800 * (X_cam / Z_cam) + ppx  (vs u_old = 400 * ...)
  
  For same 3D point: u_new ≈ 2 * u_old (approximately double)
  
Visual effect:
  - Projected image coordinates INCREASE
  - Objects appear LARGER (zoom in effect)
  - Field of view DECREASES (narrower, telephoto lens)
  - Details appear magnified
```

#### Case 2: Decrease fx and fy (Smaller Focal Length)

```
Example: fx = 800 → fx = 400

Effect on projection:
  u_new = 400 * (X_cam / Z_cam) + ppx  (vs u_old = 800 * ...)
  
  For same 3D point: u_new ≈ 0.5 * u_old (approximately halved)
  
Visual effect:
  - Projected image coordinates DECREASE
  - Objects appear SMALLER (zoom out effect)
  - Field of view INCREASES (wider, wide-angle lens)
  - More of scene visible
```

#### Case 3: Asymmetric Focal Lengths (fx ≠ fy)

```
Example: fx = 800, fy = 400

Effect:
  - Different magnification in x and y directions
  - Objects appear stretched vertically
  - Non-square pixels
  - Aspect ratio distortion
  
Result: Non-uniform scaling of image
```

### Qualitative Interpretation

```
Focal Length Range:
  ┌────────────────────────────────────────────┐
  │ fx,fy ≈ 0      Very wide angle (~170°)   │
  │ fx,fy = 50     Wide angle (~50°)          │
  │ fx,fy = 500    Normal (~20°)              │
  │ fx,fy = 1000   Telephoto (~10°)           │
  │ fx,fy >> 1000  Extreme telephoto (~1°)    │
  └────────────────────────────────────────────┘
```

### Mathematical Proof

```
Field of view relationship:
  θ = 2 * arctan(w / (2 * fx))
  
Where:
  - θ: Half field of view angle
  - w: Image width (pixels)
  - fx: Focal length (pixels)

As fx increases:
  - Denominator (2 * fx) increases
  - Argument of arctan decreases
  - θ decreases
  - Field of view NARROWS
```

### Pseudocode - Focal Length Exploration

```
FUNCTION explore_focal_length_effects(points_3D, colors, K_base):
  """
  Demonstrate focal length effects
  """
  
  focal_lengths = [100, 400, 800, 1600]
  
  FOR each f in focal_lengths:
    /* Create intrinsic matrix with new focal length */
    K = K_base
    K[0, 0] = f    (fx)
    K[1, 1] = f    (fy)
    
    /* Reconstruct projection matrix */
    P = K @ extrinsic[:3, :]
    
    /* Project and render */
    uv = project_point_cloud(points_3D, P)
    image = rasterize_point_cloud(uv, colors, width, height)
    
    DISPLAY with title "Focal length: " + str(f)
    
  OBSERVATIONS:
    - f = 100: Very wide, almost entire scene visible
    - f = 400: Moderate zoom
    - f = 800: Zoomed in, fewer objects visible
    - f = 1600: Very zoomed in, magnified detail
```

---

# SUMMARY: KEY ALGORITHMS

| Step | Operation | Input | Output | Key Formula |
|------|-----------|-------|--------|---|
| 1 | Extrinsic | R_c, C | [R\|t] | R=R_c^T, t=-R_c^T@C |
| 2 | Intrinsic | fx, fy, ppx, ppy | K | 3×3 calibration matrix |
| 3 | Projection | K, [R\|t] | P | P = K @ [R\|t] |
| 4 | Load Data | filename | points, colors | Open3D I/O |
| 5 | Project | points, P | uv | p'=P@p_homo, normalize |
| 6 | Rasterize | uv, colors | image | image[y,x] = color |
| 7 | Alt. View | points | image_top | New C, R_c → image |

---

# REFERENCES

- Camera Calibration: https://en.wikipedia.org/wiki/Camera_calibration
- Extrinsic Matrix: https://ksimek.github.io/2012/08/22/extrinsic/
- Projection Matrix: https://en.wikipedia.org/wiki/Camera_matrix
- Open3D: https://www.open3d.org/html/python_api/
- Z-buffering: https://en.wikipedia.org/wiki/Z-buffering
- Homogeneous Coordinates: https://en.wikipedia.org/wiki/Homogeneous_coordinates
