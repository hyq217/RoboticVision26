# Lab 2: Image Formation and Camera Fundamentals - Pseudocode

## Overview
Lab 2 covers camera projection systems, pinhole camera models, lens aberrations, and 3D-to-2D rasterization. The lab includes both coding tasks and critical thinking questions about robotic vision applications.

---

# PART 1: CODING TASKS

---

## Task 1: Simulating a Pinhole Camera

**Objective**: Implement a pinhole camera model to project 3D points onto a 2D image plane and visualize the geometry.

### Background: Pinhole Camera Model
```
The pinhole camera projects 3D world points onto a 2D image plane:

  World Point (X, Y, Z) → Camera Frame → Image Point (x', y')

Projection equations:
  x' = f * (X - cx) / (Z - cz)
  y' = f * (Y - cy) / (Z - cz)

Where:
  f = focal length
  (cx, cy, cz) = camera position
  (x', y') = 2D image coordinates
  (X, Y, Z) = 3D world coordinates
```

### Pseudocode - Pinhole Projection Function

```
FUNCTION pinhole_projection(points_3D, camera_position, focal_length):
  INPUT:
    - points_3D: N × 3 array of 3D points [X, Y, Z]
    - camera_position: [cx, cy, cz] camera center in world coordinates
    - focal_length: f, focal length of the camera
  
  INITIALIZE:
    points_2D = empty array of size N × 2
  
  FOR each point in points_3D:
    EXTRACT point coordinates: [X, Y, Z]
    
    TRANSLATE point to camera frame:
      X_cam = X - camera_position[0]
      Y_cam = Y - camera_position[1]
      Z_cam = Z - camera_position[2]
    
    CHECK if Z_cam > 0 (point is in front of camera):
      IF Z_cam <= 0:
        SKIP point (behind camera, invalid projection)
        CONTINUE
    
    APPLY perspective division:
      x' = focal_length * (X_cam / Z_cam)
      y' = focal_length * (Y_cam / Z_cam)
    
    STORE projected point: points_2D[i] = [x', y']
  
  RETURN points_2D
```

### Pseudocode - Visualization

```
FUNCTION visualize_pinhole_projection(points_3D, points_2D, camera_position, focal_length):
  INPUT:
    - points_3D: Original 3D points
    - points_2D: Projected 2D points
    - camera_position: [cx, cy, cz]
    - focal_length: f
  
  CREATE 3D plot:
    
    STEP 1: Plot 3D point cloud
      SCATTER points_3D with color='blue', label="3D Points"
    
    STEP 2: Plot camera position
      SCATTER camera_position with color='black', marker='o', label="Pinhole Camera"
    
    STEP 3: Create projection plane
      z_projection_plane = camera_position[z] - focal_length
      
      CREATE meshgrid for plane:
        x_range = linspace(-500, 500, 10)
        y_range = linspace(-500, 500, 10)
        [x_plane, y_plane] = meshgrid(x_range, y_range)
        z_plane = zeros_like(x_plane) + z_projection_plane
      
      SHIFT plane to camera position:
        x_plane_global = x_plane + camera_position[0]
        y_plane_global = y_plane + camera_position[1]
      
      PLOT_SURFACE (x_plane_global, y_plane_global, z_plane):
        color='lightgreen', alpha=0.3
    
    STEP 4: Plot projection lines and points
      FOR each (3D_point, 2D_point) pair:
        
        CONVERT 2D to global coordinates:
          proj_x_global = 2D_point[0] + camera_position[0]
          proj_y_global = 2D_point[1] + camera_position[1]
          proj_z_global = z_projection_plane
        
        DRAW line from camera to 3D point:
          PLOT line from camera_position to 3D_point
          color='gray', alpha=0.5
        
        SCATTER projection point on plane:
          SCATTER (proj_x_global, proj_y_global, proj_z_global)
          color='red', alpha=0.7
  
  SET axes labels and title
  SET view angle: elevation=20°, azimuth=30°
  DISPLAY plot
```

### Pseudocode - Parameter Variation

```
FUNCTION explore_camera_parameters():
  
  BASE_CAMERA_POSITION = [50, 50, 50]
  BASE_FOCAL_LENGTH = 50
  
  EXPERIMENT 1: Vary focal length
    FOR f in [25, 50, 100]:
      points_2D = pinhole_projection(points_3D, BASE_CAMERA_POSITION, f)
      VISUALIZE results
      OBSERVE:
        - Smaller f: smaller projected image
        - Larger f: larger projected image (zoom in effect)
  
  EXPERIMENT 2: Vary camera position
    POSITIONS = [
      [25, 25, 25],   # Closer to origin
      [50, 50, 50],   # Original
      [100, 100, 100] # Farther from origin
    ]
    
    FOR position in POSITIONS:
      points_2D = pinhole_projection(points_3D, position, BASE_FOCAL_LENGTH)
      VISUALIZE results
      OBSERVE:
        - Different viewing angles
        - Different projection sizes
```

---

## Task 2: Handling Lens Aberrations (Radial Distortion)

**Objective**: Simulate barrel and pincushion distortion caused by lens imperfections.

### Background: Radial Distortion

```
Radial distortion model:
  r = sqrt(x² + y²)  (distance from center)
  
  x' = x * (1 + k * r²)
  y' = y * (1 + k * r²)
  
Where:
  k > 0: Barrel distortion (outward bulging)
  k < 0: Pincushion distortion (inward pinching)
  k = 0: No distortion
```

### Pseudocode - Radial Distortion Function

```
FUNCTION apply_radial_distortion(x, y, distortion_coefficient):
  INPUT:
    - x: Original image point x coordinate
    - y: Original image point y coordinate
    - distortion_coefficient: k parameter
  
  CALCULATE radius from center:
    r = sqrt(x² + y²)
  
  APPLY distortion formula:
    distortion_factor = 1 + distortion_coefficient * r²
    x_distorted = x * distortion_factor
    y_distorted = y * distortion_factor
  
  RETURN [x_distorted, y_distorted]
```

### Pseudocode - Full Image Distortion

```
FUNCTION apply_distortion_to_image(image_path, distortion_coefficient):
  INPUT:
    - image_path: Path to input image
    - distortion_coefficient: k parameter for distortion
  
  STEP 1: Load image
    image = read_image(image_path)
    height, width = image dimensions
    original_image = convert_to_RGB(image)
  
  STEP 2: Create normalized coordinate grid
    CREATE meshgrid for image coordinates:
      x_coords = linspace(0, width-1, width)
      y_coords = linspace(0, height-1, height)
      [X_grid, Y_grid] = meshgrid(x_coords, y_coords)
    
    NORMALIZE coordinates to [-1, 1] centered at image center:
      center_x = width / 2
      center_y = height / 2
      x_norm = (X_grid - center_x) / max(width, height)
      y_norm = (Y_grid - center_y) / max(width, height)
  
  STEP 3: Apply distortion
    FOR each pixel (i, j):
      x_norm[i, j], y_norm[i, j] = apply_radial_distortion(
        x_norm[i, j], 
        y_norm[i, j], 
        distortion_coefficient
      )
  
  STEP 4: Convert back to image coordinates
    x_distorted = x_norm * max(width, height) + center_x
    y_distorted = y_norm * max(width, height) + center_y
  
  STEP 5: Create distorted image through interpolation
    distorted_image = empty array same size as original_image
    
    FOR each pixel (i, j) in distorted_image:
      source_x = x_distorted[i, j]
      source_y = y_distorted[i, j]
      
      IF source coordinates are within image bounds:
        distorted_image[i, j] = INTERPOLATE(
          original_image, 
          source_x, 
          source_y
        )
      ELSE:
        distorted_image[i, j] = 0 (or padding value)
  
  RETURN distorted_image
```

### Pseudocode - Visualization

```
FUNCTION visualize_distortion_effects(image_path):
  INPUT:
    - image_path: Path to image file
  
  STEP 1: Load original image
    original_image = read_image(image_path)
  
  STEP 2: Apply barrel distortion
    k_barrel = 0.01  (positive coefficient)
    barrel_image = apply_distortion_to_image(image_path, k_barrel)
  
  STEP 3: Apply pincushion distortion
    k_pincushion = -0.05  (negative coefficient)
    pincushion_image = apply_distortion_to_image(image_path, k_pincushion)
  
  STEP 4: Create side-by-side visualization
    CREATE 1×3 subplot layout
    
    SUBPLOT 1:
      IMSHOW original_image
      SET title "Original Image"
    
    SUBPLOT 2:
      IMSHOW barrel_image
      SET title "Barrel Distortion (k=0.01)"
      ANNOTATION: "Outward bulging effect"
    
    SUBPLOT 3:
      IMSHOW pincushion_image
      SET title "Pincushion Distortion (k=-0.05)"
      ANNOTATION: "Inward pinching effect"
    
    ADJUST layout and DISPLAY
```

### Pseudocode - Parameter Exploration

```
FUNCTION explore_distortion_parameters(image_path):
  
  k_values = [-0.1, -0.05, 0, 0.01, 0.05]
  
  FOR each k in k_values:
    distorted = apply_distortion_to_image(image_path, k)
    VISUALIZE with title "Distortion coefficient k=" + k
    OBSERVE:
      - k = 0: No distortion
      - k > 0: Barrel (wider field of view at edges)
      - k < 0: Pincushion (narrower field of view at edges)
```

---

# PART 2: 3D POINT CLOUD RASTERIZATION (Reference Solution Approach)

**Note**: This section demonstrates an alternative approach using complete camera matrices, as shown in lab_solutions.ipynb

---

## Step 1-3: Camera Matrix Construction

### Pseudocode - Extrinsic Matrix from Camera Pose

```
FUNCTION construct_extrinsic_matrix(camera_center_C, rotation_matrix_R_c):
  """
  Convert camera pose [R_c | C] to extrinsic matrix [R | t]
  
  Camera pose: [R_c | C] where R_c is world rotation, C is world position
  Extrinsic matrix: [R | t] for transforming world points to camera frame
  
  Relationship: [R | t] = inverse([R_c | C])
  """
  
  INPUT:
    - camera_center_C: 3D vector of camera position in world coordinates
    - rotation_matrix_R_c: 3×3 rotation matrix describing camera orientation
  
  STEP 1: Build homogeneous camera pose matrix
    pose_matrix = identity(4)
    pose_matrix[0:3, 0:3] = R_c       (rotation)
    pose_matrix[0:3, 3] = C            (translation)
    pose_matrix[3, :] = [0, 0, 0, 1]  (homogeneous)
  
  STEP 2: Calculate extrinsic matrix as inverse
    extrinsic_matrix = inverse(pose_matrix)
    
    /* Simplified calculation using matrix properties:
    extrinsic_matrix[0:3, 0:3] = R_c^T          (transpose of rotation)
    extrinsic_matrix[0:3, 3] = -R_c^T @ C       (transformed translation)
    extrinsic_matrix[3, :] = [0, 0, 0, 1]
    */
  
  RETURN extrinsic_matrix
```

### Pseudocode - Intrinsic Matrix

```
FUNCTION construct_intrinsic_matrix(focal_length_x, focal_length_y, principal_point_x, principal_point_y, skew):
  """
  Build camera intrinsic matrix K containing calibration parameters
  """
  
  INPUT:
    - focal_length_x (fx): Focal length in x direction (pixels)
    - focal_length_y (fy): Focal length in y direction (pixels)
    - principal_point_x (ppx): Principal point offset x (pixels)
    - principal_point_y (ppy): Principal point offset y (pixels)
    - skew (s): Skew coefficient (usually 0 for most cameras)
  
  CREATE 3×3 matrix:
    K = [[fx,  s, ppx],
         [0,  fy, ppy],
         [0,   0,   1]]
  
  RETURN K
```

### Pseudocode - Projection Matrix

```
FUNCTION construct_projection_matrix(intrinsic_matrix_K, extrinsic_matrix_[R|t]):
  """
  Combine intrinsic and extrinsic matrices to form projection matrix
  
  P = K @ [R | t]
  """
  
  INPUT:
    - intrinsic_matrix_K: 3×3 camera intrinsic matrix
    - extrinsic_matrix: 3×4 extrinsic matrix [R | t]
  
  COMPUTE projection matrix:
    P = K @ extrinsic_matrix
    /* Result: 3×4 projection matrix */
  
  RETURN P (3×4 matrix)
```

---

## Step 4-6: Point Cloud Rasterization

### Pseudocode - Load and Prepare Data

```
FUNCTION load_point_cloud_data(file_path):
  """
  Load point cloud using Open3D library
  """
  
  INPUT:
    - file_path: Path to point cloud file (e.g., .ply, .pcd)
  
  LOAD point cloud:
    point_cloud = open3d.io.read_point_cloud(file_path)
  
  EXTRACT data:
    points = array(point_cloud.points)         /* N×3 array */
    colors = array(point_cloud.colors)         /* N×3 RGB values [0,1] */
  
  PRINT first 10 points and colors for verification
  
  RETURN points, colors
```

### Pseudocode - Project Point Cloud

```
FUNCTION project_point_cloud(points_3D, projection_matrix_P):
  """
  Apply projection matrix to 3D points to get 2D image coordinates
  """
  
  INPUT:
    - points_3D: N×3 array of 3D points [X, Y, Z]
    - projection_matrix_P: 3×4 projection matrix
  
  STEP 1: Convert to homogeneous coordinates
    ones = array of ones with shape (N, 1)
    points_homogeneous = CONCATENATE([points_3D, ones], axis=1)
    /* Result: N×4 matrix */
  
  STEP 2: Apply projection matrix
    projected_points = (P @ points_homogeneous.T).T
    /* Result: N×3 array (includes depth in 3rd column) */
  
  STEP 3: Normalize by Z-coordinate (perspective division)
    FOR each projected point:
      IF point[2] != 0:
        point[0] = point[0] / point[2]  (x coordinate)
        point[1] = point[1] / point[2]  (y coordinate)
  
  PRINT first 10 projected points (2D image coordinates)
  
  RETURN projected_points
```

### Pseudocode - Rasterize to Image

```
FUNCTION rasterize_point_cloud(projected_points_2D, colors, image_width, image_height):
  """
  Draw point cloud onto 2D image array
  """
  
  INPUT:
    - projected_points_2D: N×2 array of 2D image coordinates
    - colors: N×3 array of RGB color values [0, 1]
    - image_width: Width of output image (pixels)
    - image_height: Height of output image (pixels)
  
  STEP 1: Initialize image buffer
    image = zeros array of shape (image_height, image_width, 3)
  
  STEP 2: Validate point coordinates
    valid_mask = check if all coordinates are finite (no NaN, inf)
    valid_points = projected_points_2D[valid_mask]
    valid_colors = colors[valid_mask]
  
  STEP 3: Rasterize each point
    FOR each (point, color) pair in (valid_points, valid_colors):
      x = int(point[0])
      y = int(point[1])
      
      CHECK if point is within image bounds:
        IF 0 <= x < image_width AND 0 <= y < image_height:
          image[y, x] = color  /* Set pixel color */
  
  RETURN image
```

### Pseudocode - Visualization

```
FUNCTION visualize_rasterized_image(image):
  """
  Display the rasterized point cloud image
  """
  
  INPUT:
    - image: H×W×3 image array
  
  CREATE figure
  IMSHOW image with appropriate colormap
  SET title "Rasterized Point Cloud"
  REMOVE axis labels
  DISPLAY
```

---

## Step 7: Dynamic Camera Viewpoint

### Pseudocode - Alternative Camera Configuration

```
FUNCTION generate_alternative_view(points_3D, colors, image_width, image_height):
  """
  Create a new rendering from a different camera viewpoint
  """
  
  INPUT:
    - points_3D: Original 3D point cloud
    - colors: Point colors
    - image dimensions
  
  OPTION 1: Top-down view
    new_camera_center = [scene_center_x, scene_center_y, scene_max_z + offset]
    /* Camera positioned above scene looking down */
    
    new_rotation_matrix = identity(3)  /* No rotation for top-down */
  
  OPTION 2: Side view
    new_camera_center = [scene_max_x + offset, scene_center_y, scene_center_z]
    /* Camera positioned to the side */
    
    new_rotation_matrix = rotation_around_y_axis(90 degrees)
  
  OPTION 3: Custom view
    Use look_at function to generate rotation matrix:
      eye = new_camera_position
      target = point_cloud_center
      up = [0, -1, 0]  (up vector)
      
      new_rotation_matrix = look_at_matrix(eye, target, up)
  
  RECONSTRUCT camera matrices with new parameters
  PROJECT point cloud with new projection matrix
  RASTERIZE and VISUALIZE
```

---

# PART 3: CRITICAL THINKING QUESTIONS

---

## Q1: Occluded Point Problem

**Question**: What happens in the rasterization algorithm if two points project to the same pixel location?

### Pseudocode Discussion - Depth Buffering Solution

```
PROBLEM:
  If multiple 3D points project to same 2D pixel:
    - Current algorithm: Later point overwrites earlier point
    - Result: Back face or occluded objects appear in front
    - Visual artifacts and incorrect rendering

SOLUTION: Depth/Z-Buffer Algorithm

FUNCTION rasterize_with_depth_buffer(projected_points, colors, depths, image_width, image_height):
  
  INITIALIZE:
    image = zeros(image_height, image_width, 3)
    depth_buffer = +infinity array of shape (image_height, image_width)
  
  FOR each point with (2D coords, color, depth):
    x, y = int(point[0]), int(point[1])
    
    IF point is within bounds:
      IF depth < depth_buffer[y, x]:  /* Point is closer */
        image[y, x] = color
        depth_buffer[y, x] = depth
      /* Else: point is occluded, skip */
  
  RETURN image
```

---

## Q2: Point Scaling

**Question**: How would you scale the projected points?

### Pseudocode Discussion - Scaling Operations

```
SCALING METHOD 1: Scale in 3D before projection
  
  FUNCTION scale_point_cloud(points_3D, scale_factor):
    scaled_points = points_3D * scale_factor
    RETURN scaled_points
  
  /* Project scaled_points using standard projection */
  /* Effect: All points scale uniformly in image space */

SCALING METHOD 2: Scale in image space after projection
  
  FUNCTION scale_2D_image(image, scale_factor):
    new_height = int(height * scale_factor)
    new_width = int(width * scale_factor)
    INTERPOLATE image to new dimensions
    RETURN scaled_image
  
  /* Effect: Scales the entire rendered image */

SCALING METHOD 3: Point size rendering
  
  FUNCTION rasterize_with_point_size(projected_points, colors, point_radius):
    FOR each point:
      x_center, y_center = projected_point
      
      FOR radius in range(-point_radius, point_radius):
        FOR radius_y in range(-point_radius, point_radius):
          IF distance from center <= point_radius:
            image[y_center + radius_y, x_center + radius] = color
  
  /* Effect: Each point rendered as circle of given radius */
```

---

## Q3: Focal Length Effects

**Question**: What is the affect of increasing/decreasing fx and fy values?

### Pseudocode Discussion - Focal Length Analysis

```
FOCAL LENGTH PARAMETERS:
  fx = focal length in x direction (pixels)
  fy = focal length in y direction (pixels)
  
  In intrinsic matrix K:
    K = [[fx,  0, ppx],
         [0, fy, ppy],
         [0,  0,   1]]

EFFECT ON PROJECTION:
  
  x_image = fx * (X_camera / Z_camera) + ppx
  y_image = fy * (Y_camera / Z_camera) + ppy

ANALYSIS:

CASE 1: Increase fx and fy (larger focal length)
  - Division by larger number (fx/Z)
  - Projected image coordinates become LARGER
  - EFFECT: Zoom in / Magnification
  - Result: Objects appear closer, larger field of view

CASE 2: Decrease fx and fy (smaller focal length)
  - Division by smaller number (fx/Z)
  - Projected image coordinates become SMALLER
  - EFFECT: Zoom out / Demagnification
  - Result: Objects appear farther, narrower field of view

CASE 3: Asymmetric focal lengths (fx ≠ fy)
  - Differential scaling in x and y directions
  - EFFECT: Non-uniform scaling/distortion
  - Result: Aspect ratio changes (objects appear stretched/compressed)

VISUAL INTERPRETATION:
  fx, fy ≈ 0:    Very wide angle lens (many degrees per pixel)
  fx, fy = 50:   Normal/moderate zoom
  fx, fy ≈ 1000: Extreme telephoto/zoom lens (few degrees per pixel)
```

---

## Summary of Key Algorithms

| Operation | Complexity | Key Formula | Notes |
|-----------|-----------|---|---|
| Pinhole Projection | O(N) | x' = f(X-cx)/(Z-cz) | Fast, geometrically accurate |
| Radial Distortion | O(W×H) | x'=x(1+kr²) | Quadratic in pixel distance |
| Point Cloud Projection | O(N) | p' = P·p_homo | Includes matrix multiplication |
| Rasterization | O(N) | image[y,x] = color | Depends on point density |
| Depth Buffering | O(N) | if depth < buffer | Resolves occlusion |

---

## References

- Pinhole Camera Model: https://en.wikipedia.org/wiki/Pinhole_camera_model
- Camera Intrinsics: https://en.wikipedia.org/wiki/Camera_matrix
- Radial Distortion: https://en.wikipedia.org/wiki/Distortion_(optics)#Radial
- Open3D Documentation: https://www.open3d.org/html/python_api/open3d.geometry.PointCloud.html
- Extrinsic Matrix: https://ksimek.github.io/2012/08/22/extrinsic/
- Depth Buffer Algorithm: https://en.wikipedia.org/wiki/Z-buffering
