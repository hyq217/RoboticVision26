# Lab 4: Camera Calibration, Single-View Metrology & Photometric Image Formation - Pseudocode

## Overview
Lab 4 focuses on camera calibration to determine intrinsic parameters and distortion coefficients, then applies these to undistort images and recover 3D scene information. The lab covers single-view metrology using perspective geometry and introduces reflectance models for photometric image formation.

---

# PART 1: CAMERA CALIBRATION

**Objective**: Determine camera matrix and distortion coefficients using chessboard calibration images.

## Background: Camera Calibration Process

```
Camera calibration aims to find:
1. Intrinsic parameters (camera matrix K):
   - Focal length (fx, fy)
   - Principal point (cx, cy)
   - Skew coefficient (s)

2. Distortion coefficients:
   - Radial distortion (k1, k2, k3): models barrel/pincushion effects
   - Tangential distortion (p1, p2): models decentering effects

3. Extrinsic parameters (R, t) for each image:
   - Rotation matrix and translation vector relative to world coordinates

The calibration uses a known pattern (chessboard) with known geometry
to establish correspondences between 3D world points and 2D image points.
```

---

## Step 1: Define Corner Detection Criteria

**Objective**: Set termination criteria for corner refinement algorithm.

### Pseudocode - Corner Detection Setup

```
FUNCTION setup_corner_detection_criteria():
  """
  Define termination criteria for iterative corner refinement
  """
  
  OUTPUT:
    Termination criteria tuple combining:
    - Type: cv.TERM_CRITERIA_EPS (stop when epsilon threshold reached)
           cv.TERM_CRITERIA_MAX_ITER (stop after max iterations)
           Combined with bitwise OR
    - Max iterations: typically 30
    - Epsilon (tolerance): typically 0.001
  
  criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)
  
  RETURN criteria
```

## Step 2: Prepare Object Points (3D World Coordinates)

**Objective**: Create array of known 3D chessboard corner positions.

### Pseudocode - Object Points Preparation

```
FUNCTION prepare_object_points(chessboard_width, chessboard_height):
  """
  Generate 3D coordinates for chessboard corners on XY plane (Z=0)
  """
  
  INPUT:
    - chessboard_width: Number of corners in horizontal direction (e.g., 8)
    - chessboard_height: Number of corners in vertical direction (e.g., 6)
  
  STEP 1: Create zero array
    total_corners = chessboard_width * chessboard_height
    objp = zeros((total_corners, 3), dtype=float32)
    /* Each corner: [X, Y, Z] with Z=0 (planar chessboard) */
  
  STEP 2: Generate grid using mgrid
    grid = meshgrid(range(chessboard_width), range(chessboard_height))
    /* Creates coordinate grids */
    
    objp[:, 0:2] = reshape(grid, -1, 2)
    /* Fill first two columns with (X, Y) coordinates */
    /* objp[:, 2] remains 0 for Z-coordinate */
  
  RESULT:
    objp = [[0, 0, 0],
            [1, 0, 0],
            [2, 0, 0],
            ...
            [chessboard_width-1, chessboard_height-1, 0]]
  
  RETURN objp
```

## Step 3: Detect Chessboard Corners in Images

**Objective**: Find 2D chessboard corner positions in calibration images.

### Pseudocode - Chessboard Corner Detection

```
FUNCTION detect_chessboard_corners(image_paths, chessboard_size, criteria):
  """
  Process all calibration images to find chessboard corners
  """
  
  INPUT:
    - image_paths: List of paths to calibration images
    - chessboard_size: (width, height) tuple, e.g., (8, 6)
    - criteria: Corner refinement criteria
  
  OUTPUT:
    - objpoints: List of 3D object point arrays (one per successful image)
    - imgpoints: List of 2D image point arrays (one per successful image)
  
  INITIALIZATION:
    objpoints = []
    imgpoints = []
    object_points_template = prepare_object_points(...)
  
  MAIN LOOP:
    FOR each image_path in image_paths:
      
      STEP 1: Load and convert image
        image = read_image(image_path)
        gray = convert_to_grayscale(image)
      
      STEP 2: Find chessboard corners
        success, corners = find_chessboard_corners(
          gray, 
          chessboard_size,
          flags=0
        )
        /* Returns: success (bool), corners (N×1×2 array) */
      
      IF success:
        
        STEP 3: Add object points
          objpoints.append(object_points_template)
          /* Same 3D points for every successful detection */
        
        STEP 4: Refine corner positions
          refined_corners = corner_sub_pixel(
            gray,
            corners,
            window_size=(11, 11),   /* Search window around corner */
            zone=(-1, -1),          /* No dead zone */
            criteria=criteria
          )
          imgpoints.append(refined_corners)
        
        STEP 5: Visualize results
          draw_chessboard_corners(
            image,
            chessboard_size,
            refined_corners,
            success
          )
          display_image(image, title=f"Corners in {image_path}")
      
      ELSE:
        SKIP (no corners detected in this image)
  
  RETURN objpoints, imgpoints
```

## Step 4: Calibrate Camera

**Objective**: Compute camera matrix and distortion coefficients.

### Pseudocode - Camera Calibration

```
FUNCTION calibrate_camera(objpoints, imgpoints, image_size):
  """
  Solve for camera intrinsic parameters and distortion coefficients
  """
  
  INPUT:
    - objpoints: List of 3D point arrays from successful images
    - imgpoints: List of 2D point arrays from successful images
    - image_size: (width, height) of images
  
  OUTPUT:
    - ret: Reprojection error (scalar)
    - mtx: Camera matrix (3×3)
    - dist: Distortion coefficients (5×1 or more)
    - rvecs: Rotation vectors (one per image)
    - tvecs: Translation vectors (one per image)
  
  STEP 1: Perform calibration
    ret, mtx, dist, rvecs, tvecs = calibrate_camera_matrix(
      objpoints,
      imgpoints,
      image_size,
      camera_matrix=None,      /* Auto-initialize */
      distortion_coeffs=None   /* Auto-initialize */
    )
  
  STEP 2: Print results
    PRINT "Camera matrix (mtx):"
    PRINT mtx  /* 3×3 matrix with fx, fy, cx, cy */
    
    PRINT "Distortion coefficients (dist):"
    PRINT dist  /* [k1, k2, p1, p2, k3, ...] */
    
    PRINT "Reprojection error:", ret
  
  RETURN ret, mtx, dist, rvecs, tvecs
```

## Camera Matrix Structure

```
mtx = [[fx,  0, cx],
       [0,  fy, cy],
       [0,   0,  1]]

Where:
  fx, fy: Focal lengths (pixels)
  cx, cy: Principal point (optical center, pixels)
```

## Distortion Coefficients

```
dist = [k1, k2, p1, p2, k3]  (5 or 8 coefficients)

Where:
  k1, k2, k3: Radial distortion (barrel/pincushion)
  p1, p2: Tangential distortion (decentering)

Radial distortion formula:
  x_distorted = x * (1 + k1*r² + k2*r⁴ + k3*r⁶)
  y_distorted = y * (1 + k1*r² + k2*r⁴ + k3*r⁶)
  
Where r² = x² + y² (distance from optical center)
```

---

# PART 2: IMAGE UNDISTORTION

**Objective**: Remove lens distortion from images using calibrated parameters.

## Step 1: Optimize Camera Matrix

**Objective**: Compute optimal camera matrix for desired output.

### Pseudocode - Get Optimal Camera Matrix

```
FUNCTION optimize_camera_matrix(mtx, dist, image_size, alpha):
  """
  Refine camera matrix based on scaling parameter
  """
  
  INPUT:
    - mtx: Camera matrix from calibration
    - dist: Distortion coefficients from calibration
    - image_size: (width, height) of images
    - alpha: Scaling parameter (0.0 to 1.0)
      * alpha = 0: Minimal unwanted pixels (may crop corners)
      * alpha = 1: All pixels retained (may have black borders)
  
  OUTPUT:
    - new_mtx: Refined camera matrix (3×3)
    - roi: Region of interest (x, y, width, height)
  
  new_mtx, roi = get_optimal_camera_matrix(
    mtx,
    dist,
    image_size,
    alpha
  )
  
  RETURN new_mtx, roi
```

## Step 2: Method 1 - Direct Undistortion

**Objective**: Use cv.undistort() to directly remove distortion.

### Pseudocode - Direct Undistortion Method

```
FUNCTION undistort_image_direct(distorted_image, mtx, dist, new_mtx, roi):
  """
  Remove distortion using direct undistortion
  """
  
  INPUT:
    - distorted_image: Original distorted image
    - mtx: Original camera matrix
    - dist: Distortion coefficients
    - new_mtx: Optimized camera matrix
    - roi: Region of interest (x, y, w, h)
  
  STEP 1: Apply undistortion
    undistorted = undistort_image(
      distorted_image,
      mtx,
      dist,
      new_camera_matrix=new_mtx
    )
  
  STEP 2: Optionally crop using ROI
    x, y, width, height = roi
    undistorted_cropped = undistorted[y : y+height, x : x+width]
  
  STEP 3: Display results
    DISPLAY undistorted_cropped
  
  RETURN undistorted_cropped
```

### Algorithm Explanation

```
Direct undistortion process:
  1. For each pixel (u', v') in output image:
     - Apply inverse of distortion model to find (u, v) in distorted image
     - Interpolate pixel value from distorted image at (u, v)
     - Write to output image at (u', v')
  
  2. Result: Distortion removed, image appears rectilinear
```

## Step 3: Method 2 - Remapping Undistortion

**Objective**: Use pre-computed mapping for faster repeated undistortions.

### Pseudocode - Remapping Undistortion Method

```
FUNCTION undistort_image_remap(distorted_image, mtx, dist, new_mtx, image_size):
  """
  Remove distortion using precomputed maps (faster for batch processing)
  """
  
  INPUT:
    - distorted_image: Original distorted image
    - mtx: Original camera matrix
    - dist: Distortion coefficients
    - new_mtx: Optimized camera matrix
    - image_size: (width, height)
  
  STEP 1: Create undistortion maps
    mapx, mapy = init_undistort_rectify_map(
      mtx,
      dist,
      rectification_matrix=None,  /* Identity for no rectification */
      new_camera_matrix=new_mtx,
      image_size=image_size,
      map_type=cv.CV_32F  /* Or cv.CV_16SC2 for faster remap */
    )
    
    OUTPUT:
      mapx: Map for x-coordinates (width × height)
      mapy: Map for y-coordinates (width × height)
      
    Each (mapx[i,j], mapy[i,j]) tells where to sample from
    the distorted image for output pixel (i, j)
  
  STEP 2: Apply remapping
    undistorted = remap_pixels(
      distorted_image,
      mapx,
      mapy,
      interpolation=cv.INTER_LINEAR  /* Or cv.INTER_NEAREST */
    )
  
  STEP 3: Display
    DISPLAY undistorted
  
  RETURN undistorted
```

### Advantage of Remapping

```
Benefits:
  - Faster for processing many images with same camera
  - Maps computed once, reused for all images
  - Better for real-time applications
  
Trade-off:
  - Slightly more complex code
  - Requires intermediate map storage
```

---

# PART 3: REPROJECTION ERROR EVALUATION

**Objective**: Quantify calibration accuracy by comparing detected vs projected points.

## Pseudocode - Reprojection Error Calculation

```
FUNCTION calculate_reprojection_error(objpoints, imgpoints, rvecs, tvecs, mtx, dist):
  """
  Compute average reprojection error across all calibration images
  """
  
  INPUT:
    - objpoints: List of 3D point arrays
    - imgpoints: List of 2D image point arrays (detected)
    - rvecs: List of rotation vectors (from calibration)
    - tvecs: List of translation vectors (from calibration)
    - mtx: Camera matrix (from calibration)
    - dist: Distortion coefficients (from calibration)
  
  OUTPUT:
    - mean_error: Average reprojection error (pixels)
  
  INITIALIZATION:
    total_error = 0.0
  
  MAIN LOOP:
    FOR i = 0 to length(objpoints):
      
      STEP 1: Project 3D points to image plane
        projected_2d_points, _ = project_points(
          objpoints[i],      /* 3D world coordinates */
          rvecs[i],          /* Rotation vector */
          tvecs[i],          /* Translation vector */
          mtx,               /* Camera matrix */
          dist               /* Distortion coefficients */
        )
        /* Output: N×1×2 array of projected 2D points */
      
      STEP 2: Calculate error for this image
        /* Reshape for easier computation */
        detected = reshape(imgpoints[i], -1, 2)
        projected = reshape(projected_2d_points, -1, 2)
        
        /* Compute Euclidean distance between detected and projected */
        error_vector = detected - projected
        distances = norm(error_vector, axis=1)
        
        /* Average error for this image */
        image_error = mean(distances)
      
      STEP 3: Accumulate total error
        total_error += image_error
  
  STEP 4: Compute mean
    mean_error = total_error / length(objpoints)
  
  STEP 5: Report
    PRINT f"Mean reprojection error: {mean_error:.4f} pixels"
  
  RETURN mean_error
```

## Interpreting Reprojection Error

```
Error magnitude:
  < 0.5 pixels: Excellent calibration
  0.5 - 1.0 pixels: Good calibration
  1.0 - 2.0 pixels: Acceptable
  > 2.0 pixels: Poor calibration, consider:
    - Using more calibration images
    - Improving chessboard detection
    - Using larger chessboard patterns
    - Checking for image quality issues
```

---

# PART 4: REFLECTION QUESTIONS & ANSWERS

---

## Q1: Goals and Importance of Camera Calibration

**Question**: What is the goal of camera calibration, and why do we need a sufficient number of correspondences?

### Answer Structure

```
GOAL OF CAMERA CALIBRATION:

1. Determine intrinsic parameters:
   - Focal length (fx, fy)
   - Principal point (cx, cy)
   - Skew coefficient (s)
   RESULT: Camera matrix K (3×3)

2. Determine distortion coefficients:
   - Radial distortion (k1, k2, k3)
   - Tangential distortion (p1, p2)
   RESULT: Distortion vector (5×1 or more)

3. Determine extrinsic parameters (per image):
   - Camera position (translation vector t)
   - Camera orientation (rotation matrix R)

WHY SUFFICIENT CORRESPONDENCES ARE NEEDED:

1. Parameter estimation:
   - System of equations: number of unknowns ≈ 11 (intrinsic + distortion)
   - Each correspondence provides 2 equations (x and y)
   - Overdetermined system (more equations than unknowns) needed for
     least-squares optimization
   
2. Robustness to noise:
   - Real measurements contain noise and errors
   - Multiple correspondences allow averaging out measurement errors
   - Result: More stable and accurate parameter estimates
   
3. Complete image coverage:
   - Distortion varies across image plane
   - Corners often have most distortion
   - Correspondences needed across entire image
   - Otherwise: Poor distortion model in some regions
   
4. Avoid degeneracy:
   - Too few correspondences: Underdetermined system
   - May have multiple valid solutions
   - Or no unique solution at all
   
RECOMMENDATION:
  - Minimum: 10-15 calibration images
  - Typical: 20-30 images
  - Each image: 40-60 detected corners
  - Total correspondences: 800-1800 (typically 1500+)
```

---

## Q2: Single-View Metrology with Perspective Geometry

**Question**: How can perspective projection and vanishing lines help infer scene structure?

### Answer Structure

```
PERSPECTIVE PROJECTION BASICS:
  - Parallel lines in 3D converge to vanishing points in 2D image
  - Vanishing point = limit of parallel lines under projection
  - Multiple vanishing points: multiple orientations in scene
  
VANISHING LINES:
  - Lines connecting vanishing points in image
  - Represent planes in 3D space
  - Horizon line = vanishing line of ground plane
  - Vertical lines = vanishing line of vertical planes
  
APPLICATIONS FOR SCENE UNDERSTANDING:

1. Plane identification:
   - Vanishing lines tell us which image regions correspond to planes
   - Example: Horizon line separates sky (upper plane) from ground
   
2. 3D orientation measurement:
   - Vanishing point direction ∝ plane normal direction
   - Multiple vanishing points → multiple plane normals
   - Can compute angles between planes
   
3. Metric measurements (with calibration):
   - If we know camera calibration (K)
   - And can identify reference objects/dimensions
   - Vanishing points allow:
     * Computing 3D coordinates
     * Measuring distances and heights
     * Determining relative depths
   
4. Cross-ratio preservation:
   - Perspective projection preserves cross-ratios
   - For 4 collinear points: (p1-p3)(p2-p4) / (p1-p4)(p2-p3) = constant
   - Allows measurements along lines without full 3D knowledge
   
5. Image rectification:
   - Transform image to remove perspective distortion
   - Use vanishing lines to compute rectification homography
   - Result: Planar regions appear as if viewed from front
   - Easier to measure distances and angles in rectified regions
   
6. Height estimation:
   - Ground plane vanishing line identified
   - Object base and top detected in image
   - Using geometry: height ∝ (image_distance × distance_to_plane) / focal_length
   
WORKFLOW EXAMPLE:
  1. Detect vanishing points (intersection of parallel lines)
  2. Compute vanishing line (connecting vanishing points)
  3. Identify plane in scene (from vanishing line)
  4. If calibrated + reference object known:
     - Compute 3D coordinates of any point in that plane
     - Measure distances and scales
```

---

## Q3: Reflectance Models in Photometric Image Formation

**Question**: How do reflectance models affect interpretation of image intensities?

### Answer Structure

```
REFLECTANCE MODELS: Describe light-surface interactions

MODEL 1: LAMBERTIAN (DIFFUSE) REFLECTANCE
  
  Assumption:
    - Perfectly matte surface
    - Reflects light equally in all directions
  
  Intensity equation:
    I(x) = ρ(x) × (n(x) · l)
    
    Where:
      I: Image intensity at pixel x
      ρ: Albedo (surface reflectivity, constant per surface)
      n: Surface normal (3D unit vector)
      l: Light direction (3D unit vector)
      (n · l): Cosine of angle between normal and light
  
  Key properties:
    - Intensity depends ONLY on angle between normal and light
    - Viewing angle does NOT affect intensity
    - Appears uniformly bright from any viewing direction
    - Bright when light hits surface perpendicularly (n·l=1)
    - Dark when light is parallel to surface (n·l≈0)
  
  For computer vision:
    - Shape-from-shading: Can recover surface normal from intensity
    - Photometric stereo: Use multiple lights to compute normals
    - Direct relationship: intensity ↔ surface orientation
    - Very useful for 3D reconstruction!
  
  Examples: chalk, matte paint, unglazed ceramic


MODEL 2: SPECULAR (MIRROR-LIKE) REFLECTANCE
  
  Assumption:
    - Mirror-like surface
    - Reflects light at angle of incidence
  
  Intensity equation:
    I(x) = ρ × (r · v)^n
    
    Where:
      r: Reflection direction (computed from l and n)
      v: Viewing direction
      n: Shininess coefficient (higher = shinier)
  
  Key properties:
    - Intensity depends on BOTH lighting AND viewing direction
    - Creates bright highlights (specular highlights)
    - Highlight location moves with viewing angle
    - Can be very bright (point light source reflection)
    - Reflection direction = mirror reflection
  
  For computer vision:
    - Shape recovery harder (non-linear with surface normal)
    - Highlights provide information about lighting direction
    - Viewing-dependent intensities problematic for shape-from-shading
    - Photometric stereo needs specialized algorithms
  
  Examples: mirror, polished metal, still water


HYBRID MODELS: Real surfaces exhibit both diffuse + specular

  Intensity equation (Phong model):
    I = k_d × ρ × (n · l) + k_s × (r · v)^n + k_a
    
    Where:
      k_d: Diffuse coefficient (0 to 1)
      k_s: Specular coefficient (0 to 1)
      k_a: Ambient lighting term
  
  Interpretation:
    - k_d = 1, k_s = 0: Pure Lambertian
    - k_d = 0, k_s = 1: Pure specular
    - 0 < k_d, k_s < 1: Realistic material


EFFECTS ON IMAGE INTERPRETATION:

1. Shape recovery reliability:
   Lambertian:  ✓ Reliable (direct intensity-to-normal mapping)
   Specular:    ✗ Unreliable (highlights confuse algorithms)
   Hybrid:      △ Moderate (need to separate components)

2. Photometric stereo:
   Lambertian:  ✓ Standard algorithm works well
   Specular:    ✗ Need robust outlier handling or specialized algorithms
   Hybrid:      △ May need preprocessing to remove highlights

3. Algorithm selection:
   Lambertian:  - Shape-from-shading
                - Standard photometric stereo
                - Direct normal estimation
   
   Specular:    - Specular photometric stereo (more images needed)
                - Polarization-based methods
                - Highlight analysis
   
   Hybrid:      - Multi-model approaches
                - Robust estimation with outlier rejection
                - Component separation

4. Lighting considerations:
   Lambertian:  - Can use distant light (parallel rays)
                - Point light sources work too
                - Less sensitive to light position
   
   Specular:    - Light position critical
                - Viewing geometry crucial
                - Shadows and specular highlights contain information

5. Material recognition:
   - Diffuse-heavy materials: Matte appearance (paint, fabric, paper)
   - Specular-heavy materials: Shiny appearance (plastic, metal, glass)
   - Ratio k_d/k_s helps classify material types


PRACTICAL CONSIDERATIONS:

For computer vision systems:
  1. Identify which model applies:
     - Examine image for highlights (specular present?)
     - Check if brightness varies smoothly with geometry
     - Test algorithm assumptions
  
  2. Choose preprocessing:
     - Remove highlights (specular surfaces)
     - Normalize lighting (for shape recovery)
     - Apply edge detection (to find boundaries)
  
  3. Select algorithm:
     - Lambertian surfaces: Use direct methods
     - Specular surfaces: Use robust methods with outlier rejection
     - Mixed: Use multi-model approaches
  
  4. Validate results:
     - Check reprojection under different lighting
     - Verify recovered shapes match visual appearance
     - Test with known objects/lighting
```

---

# SUMMARY: KEY ALGORITHMS

| Operation | Input | Output | Complexity | Accuracy |
|-----------|-------|--------|-----------|----------|
| Corner detection | Gray image | Nx2 corner array | O(W×H) | ±0.5 pixels (refined) |
| Calibration | Objpoints, imgpoints | K, dist, R, t | O(N×M²) | 0.5-2.0 px RMS error |
| Direct undistort | Image, K, dist | Undistorted image | O(W×H) | Exact (within interpolation) |
| Remap undistort | Image, mapx, mapy | Undistorted image | O(W×H) | Same as direct |
| Reprojection error | 3D, 2D, K, dist, R, t | Error scalar | O(N×M) | Ground truth |

---

# WORKFLOW CHECKLIST

```
CALIBRATION WORKFLOW:
☐ Step 1: Load calibration images (10-30 with chessboard)
☐ Step 2: Define chessboard pattern size (e.g., 8x6)
☐ Step 3: Set up corner detection criteria
☐ Step 4: Generate object points template
☐ Step 5: For each image:
  ☐ Convert to grayscale
  ☐ Detect corners with findChessboardCorners
  ☐ Refine corners with cornerSubPix
  ☐ Add to lists
☐ Step 6: Calibrate with calibrateCamera
☐ Step 7: Calculate reprojection error
☐ Step 8: If error acceptable, proceed; else recalibrate

UNDISTORTION WORKFLOW:
☐ Step 1: Load calibrated camera parameters (K, dist)
☐ Step 2: Load image to undistort
☐ Step 3: Compute optimal camera matrix
☐ Step 4: Choose method:
  ☐ Method 1 (Direct): Use undistort()
  ☐ Method 2 (Remap): Use initUndistortRectifyMap + remap
☐ Step 5: Display and save results
☐ Step 6: Verify undistortion quality visually
```

---

# REFERENCES

- OpenCV Camera Calibration: https://docs.opencv.org/4.x/dc/dbb/tutorial_py_calibration.html
- Camera Calibration Mathematics: https://en.wikipedia.org/wiki/Camera_resectioning
- Distortion Models: https://en.wikipedia.org/wiki/Lens_distortion
- Single-View Geometry: https://en.wikipedia.org/wiki/Vanishing_point
- Photometric Image Formation: https://en.wikipedia.org/wiki/Photometric_stereo
- Reflectance Models: https://en.wikipedia.org/wiki/Phong_reflection_model
- Lambertian vs Specular: https://en.wikipedia.org/wiki/Specular_reflection
